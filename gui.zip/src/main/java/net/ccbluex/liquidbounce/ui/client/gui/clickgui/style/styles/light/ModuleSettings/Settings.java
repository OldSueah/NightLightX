/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Mouse
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.light.ModuleSettings;

import java.awt.Color;
import net.ccbluex.liquidbounce.features.value.BoolValue;
import net.ccbluex.liquidbounce.features.value.FloatValue;
import net.ccbluex.liquidbounce.features.value.IntegerValue;
import net.ccbluex.liquidbounce.features.value.ListValue;
import net.ccbluex.liquidbounce.features.value.TextValue;
import net.ccbluex.liquidbounce.features.value.Value;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.light.ModuleSettings.Setting;
import net.ccbluex.liquidbounce.utils.AnimationHelper;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import org.lwjgl.input.Mouse;

public class Settings
extends Setting {
    private final AnimationHelper alphaAnim;

    public Settings(AnimationHelper alphaAnim) {
        this.alphaAnim = alphaAnim;
    }

    @Override
    public void drawListValue(boolean previousMouse, int mouseX, int mouseY, float mY, float startX, ListValue listValue) {
        float x = startX + 310.0f;
        int l = this.font.func_78256_a((String)listValue.get());
        this.font.drawString(listValue.getName(), startX + 210.0f, mY + 1.0f, new Color(80, 80, 80, this.alphaAnim.getAlpha()).getRGB());
        if (listValue.openList) {
            int height = listValue.getValues().length * (this.font.field_78288_b + 2);
            RenderUtils.drawRoundedRect2(x + 61.0f - (float)l, mY - 3.0f, x + 92.0f, mY + 11.0f, 2.0f, new Color(230, 230, 230, 200).getRGB());
            RenderUtils.drawRoundedRect2(x + 85.0f, mY - 6.0f, x + 201.0f, (int)(mY + (float)height + 3.0f), 2.0f, new Color(230, 230, 230, 200).getRGB());
            RenderUtils.drawRoundedRect2(x + 60.0f - (float)l, mY - 4.0f, x + 80.0f, mY + 10.0f, 2.0f, new Color(250, 250, 250, 250).getRGB());
            RenderUtils.drawRect(x + 63.0f - (float)l, mY - 4.0f, x + 90.0f, mY + 10.0f, new Color(250, 250, 250, 250).getRGB());
            this.font.drawString((String)listValue.get(), x + 70.0f - (float)l, mY + 1.0f, new Color(80, 80, 80, 250).getRGB());
            this.font.drawString(">", x + 73.0f, mY + 1.0f, new Color(80, 80, 80, 250).getRGB());
            RenderUtils.drawRoundedRect2(x + 85.0f, mY - 8.0f, x + 200.0f, (int)(mY + (float)height + 2.0f), 2.0f, new Color(250, 250, 250, 250).getRGB());
            for (int i = 0; i < listValue.getValues().length; ++i) {
                if (this.isHovered(x + 85.0f, mY - 5.0f + (float)(i * (this.font.field_78288_b + 2)), x + 200.0f, mY - 3.0f + (float)this.font.field_78288_b + (float)(i * (this.font.field_78288_b + 2)), mouseX, mouseY)) {
                    RenderUtils.drawRoundedRect2(x + 88.0f, mY - 6.0f + (float)(i * (this.font.field_78288_b + 2)), x + 197.0f, mY - 2.0f + (float)this.font.field_78288_b + (float)(i * (this.font.field_78288_b + 2)), 2.0f, new Color(220, 220, 220, 255).getRGB());
                    if (Mouse.isButtonDown((int)0) && !previousMouse) {
                        listValue.set(listValue.getValues()[i]);
                    }
                }
                if (i == listValue.getModeListNumber((String)listValue.get())) {
                    RenderUtils.drawRoundedRect2(x + 88.0f, mY - 6.0f + (float)(i * (this.font.field_78288_b + 2)), x + 197.0f, mY - 2.0f + (float)this.font.field_78288_b + (float)(i * (this.font.field_78288_b + 2)), 2.0f, new Color(200, 200, 200, 255).getRGB());
                }
                this.font.drawString(listValue.getValues()[i], x + 91.0f, mY - 2.0f + (float)(i * (this.font.field_78288_b + 2)), new Color(80, 80, 80, this.alphaAnim.getAlpha()).getRGB());
            }
        } else {
            RenderUtils.drawRoundedRect2(x + 61.0f - (float)l, mY - 3.0f, x + 81.0f, mY + 11.0f, 2.0f, new Color(230, 230, 230, 200).getRGB());
            RenderUtils.drawRoundedRect2(x + 60.0f - (float)l, mY - 4.0f, x + 80.0f, mY + 10.0f, 2.0f, new Color(250, 250, 250, 250).getRGB());
            this.font.drawString((String)listValue.get(), x + 70.0f - (float)l, mY + 1.0f, new Color(80, 80, 80, this.alphaAnim.getAlpha()).getRGB());
            this.font.drawString("<", x + 73.0f, mY + 1.0f, new Color(80, 80, 80, this.alphaAnim.getAlpha()).getRGB());
        }
        if (this.isHovered(x + 60.0f - (float)l, mY - 4.0f, x + 85.0f, mY + 11.0f, mouseX, mouseY) && Mouse.isButtonDown((int)0) && !previousMouse) {
            listValue.openList = !listValue.openList;
        }
    }

    @Override
    public void drawTextValue(float startX, float mY, TextValue textValue) {
        this.font.drawString(textValue.getName() + ": " + (String)textValue.get(), startX + 210.0f, mY, new Color(80, 80, 80).getRGB());
    }

    public String toString() {
        return "Light Client Settings";
    }

    public int hashCode() {
        return super.hashCode();
    }

    public boolean equals(Object obj) {
        return obj == this;
    }

    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    protected void finalize() throws Throwable {
        super.finalize();
    }

    @Override
    public void drawFloatValue(int mouseX, float mY, float startX, boolean previousMouse, boolean buttonDown, FloatValue floatValue) {
        float x = startX + 300.0f;
        double render = 68.0f * (((Float)floatValue.get()).floatValue() - floatValue.getMinimum()) / (floatValue.getMaximum() - floatValue.getMinimum()) + 1.0f;
        RenderUtils.drawRect(x - 6.0f, mY + 2.0f, (float)((double)x + 75.0), mY + 3.0f, new Color(200, 200, 200, this.alphaAnim.getAlpha()).getRGB());
        RenderUtils.drawRect(x - 6.0f, mY + 2.0f, (float)((double)x + render + 6.5), mY + 3.0f, new Color(61, 141, 255, this.alphaAnim.getAlpha()).getRGB());
        RenderUtils.circle((float)((double)x + render + 4.0), mY + 2.5f, 2.0f, new Color(61, 141, 255, this.alphaAnim.getAlpha()));
        this.font.drawString(String.valueOf(floatValue.get()), (float)((double)x + render - 5.0), mY - 7.0f, new Color(80, 80, 80, this.alphaAnim.getAlpha()).getRGB());
        this.font.drawString(floatValue.getName(), startX + 210.0f, mY, new Color(80, 80, 80, this.alphaAnim.getAlpha()).getRGB());
        if (buttonDown && Mouse.isButtonDown((int)0) && !previousMouse && Mouse.isButtonDown((int)0)) {
            render = floatValue.getMinimum();
            double max = floatValue.getMaximum();
            double inc = 0.01;
            double valAbs = (double)mouseX - ((double)x + 1.0);
            double perc = valAbs / 68.0;
            perc = Math.min(Math.max(0.0, perc), 1.0);
            double valRel = (max - render) * perc;
            double val = render + valRel;
            val = (double)Math.round(val * (1.0 / inc)) / (1.0 / inc);
            floatValue.set(Float.valueOf((float)val));
        }
    }

    @Override
    public void drawIntegerValue(int mouseX, float mY, float startX, boolean previousMouse, boolean buttonDown, IntegerValue integerValue) {
        float x = startX + 300.0f;
        double render = 68.0f * (float)((Integer)integerValue.get() - integerValue.getMinimum()) / (float)(integerValue.getMaximum() - integerValue.getMinimum()) + 1.0f;
        RenderUtils.drawRect(x - 6.0f, mY + 2.0f, (float)((double)x + 75.0), mY + 3.0f, new Color(200, 200, 200).getRGB());
        RenderUtils.drawRect(x - 6.0f, mY + 2.0f, (float)((double)x + render + 6.5), mY + 3.0f, new Color(61, 141, 255).getRGB());
        RenderUtils.circle((float)((double)x + render + 4.0), mY + 2.5f, 2.0f, new Color(61, 141, 255, this.alphaAnim.getAlpha()));
        this.font.drawString(String.valueOf(integerValue.get()), (float)((double)x + render - 5.0), mY - 7.0f, new Color(80, 80, 80).getRGB());
        this.font.drawString(integerValue.getName(), startX + 210.0f, mY, new Color(80, 80, 80, this.alphaAnim.getAlpha()).getRGB());
        if (buttonDown && Mouse.isButtonDown((int)0) && !previousMouse && Mouse.isButtonDown((int)0)) {
            render = integerValue.getMinimum();
            double max = integerValue.getMaximum();
            double inc = 1.0;
            double valAbs = (double)mouseX - ((double)x + 1.0);
            double perc = valAbs / 68.0;
            perc = Math.min(Math.max(0.0, perc), 1.0);
            double valRel = (max - render) * perc;
            double val = render + valRel;
            val = (double)Math.round(val * (1.0 / inc)) / (1.0 / inc);
            integerValue.set((int)val);
        }
    }

    @Override
    public void drawBoolValue(boolean mouse, int mouseX, int mouseY, float startX, float mY, BoolValue boolValue) {
        float x = startX + 325.0f;
        this.font.drawString(boolValue.getName(), startX + 210.0f, mY, new Color(80, 80, 80, this.alphaAnim.getAlpha()).getRGB());
        RenderUtils.drawRoundedRect2(x + 28.0f, mY - 4.0f, x + 52.0f, mY + 10.0f, 5.0f, (Boolean)boolValue.get() != false ? new Color(66, 134, 245, this.alphaAnim.getAlpha()).getRGB() : new Color(114, 118, 125, this.alphaAnim.getAlpha()).getRGB());
        RenderUtils.drawRoundedRect2(x + 30.0f, mY - 2.0f, x + 50.0f, mY + 8.0f, 4.0f, new Color(250, 250, 250, 255).getRGB());
        RenderUtils.circle(x + 40.0f + boolValue.getAnimation().getAnimationX(), mY + 3.0f, 4.0f, (Boolean)boolValue.get() != false ? new Color(66, 134, 245, this.alphaAnim.getAlpha()).getRGB() : new Color(174, 174, 174, this.alphaAnim.getAlpha()).getRGB());
        boolValue.getAnimation().animationX = (Boolean)boolValue.get() != false ? (float)((double)boolValue.getAnimation().animationX + (double)(5.0f - boolValue.getAnimation().animationX) / 2.5) : (float)((double)boolValue.getAnimation().animationX + (double)(-5.0f - boolValue.getAnimation().animationX) / 2.5);
        if (this.isHovered(x + 28.0f, mY - 4.0f, x + 52.0f, mY + 10.0f, mouseX, mouseY) && mouse) {
            boolValue.set((Boolean)boolValue.get() == false);
        }
    }

    @Override
    public void drawColorValue(float startX, float mY, float x, int mouseX, int mouseY, Value.ColorValue colorValue) {
        Color rainbowColor;
        this.font.drawString(colorValue.getName(), startX + 210.0f, mY - 2.0f, new Color(80, 80, 80).getRGB());
        float y = mY - 8.0f;
        double aDouble = ((double)((float)mouseX - x) / 50.0 + Math.sin(1.6)) % 1.0;
        for (int ticks = 0; ticks < 50; ++ticks) {
            rainbowColor = new Color(Color.HSBtoRGB((float)((double)ticks / 50.0 + Math.sin(1.6)) % 1.0f, 1.0f, 1.0f));
            if ((float)mouseX > x && (float)mouseX < x + 50.0f && (float)mouseY > y && (float)mouseY < y + 13.0f && Mouse.isButtonDown((int)0)) {
                colorValue.set(new Color(Color.HSBtoRGB((float)aDouble, 1.0f, 1.0f)).getRGB());
                RenderUtils.drawRect((float)(mouseX - 1), (float)(mouseY - 1), (float)(mouseX + 1), (float)(mouseY + 1), new Color(100, 100, 100, 100).getRGB());
            }
            if ((float)mouseX > x && (float)mouseX < x + 50.0f && (float)mouseY > y && (float)mouseY < y + 13.0f) {
                RenderUtils.drawRect((float)(mouseX - 1), (float)(mouseY - 1), (float)(mouseX + 1), (float)(mouseY + 1), new Color(100, 100, 100, 100).getRGB());
            }
            RenderUtils.drawRect(x + (float)ticks, y, x + (float)ticks + 1.0f, y + 13.0f, rainbowColor.getRGB());
        }
        for (int shits = 0; shits < 50; ++shits) {
            rainbowColor = new Color(Color.HSBtoRGB((float)((double)shits / 50.0 + Math.sin(1.6)) % 1.0f, 0.5f, 1.0f));
            if ((float)mouseX > x && (float)mouseX < x + 100.0f && (float)mouseY > y && (float)mouseY < y + 13.0f && Mouse.isButtonDown((int)0)) {
                colorValue.set(new Color(Color.HSBtoRGB((float)aDouble, 0.5f, 1.0f)).getRGB());
                RenderUtils.drawRect((float)(mouseX - 1), (float)(mouseY - 1), (float)(mouseX + 1), (float)(mouseY + 1), new Color(100, 100, 100, 100).getRGB());
            }
            if ((float)mouseX > x && (float)mouseX < x + 100.0f && (float)mouseY > y && (float)mouseY < y + 13.0f) {
                RenderUtils.drawRect((float)(mouseX - 1), (float)(mouseY - 1), (float)(mouseX + 1), (float)(mouseY + 1), new Color(100, 100, 100, 100).getRGB());
            }
            RenderUtils.drawRect(x + (float)shits + 50.0f, y, x + (float)shits + 51.0f, y + 13.0f, rainbowColor.getRGB());
        }
        RenderUtils.drawRect(x, y + 16.0f, x + 50.0f, y + 20.0f, (int)((Integer)colorValue.get()));
    }
}

