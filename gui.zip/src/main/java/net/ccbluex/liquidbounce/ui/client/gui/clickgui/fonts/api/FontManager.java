/*
 * Decompiled with CFR 0.152.
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui.fonts.api;

import net.ccbluex.liquidbounce.ui.client.gui.clickgui.fonts.api.FontFamily;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.fonts.api.FontType;

@FunctionalInterface
public interface FontManager {
    public FontFamily fontFamily(FontType var1);
}

