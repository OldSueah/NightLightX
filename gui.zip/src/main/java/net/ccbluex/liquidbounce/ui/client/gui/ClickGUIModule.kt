/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.network.Packet
 *  net.minecraft.network.play.server.S2EPacketCloseWindow
 */
package net.ccbluex.liquidbounce.ui.client.gui;

import java.awt.Color;
import java.util.Locale;
import jdk.nashorn.internal.codegen.ResourceMonitor;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import net.ccbluex.liquidbounce.event.EventTarget;
import net.ccbluex.liquidbounce.event.PacketEvent;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.module.ModuleInfo;
import net.ccbluex.liquidbounce.features.value.BoolValue;
import net.ccbluex.liquidbounce.features.value.FloatValue;
import net.ccbluex.liquidbounce.features.value.IntegerValue;
import net.ccbluex.liquidbounce.features.value.ListValue;
import net.ccbluex.liquidbounce.ui.client.gui.ClickGUIModule;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.ClickGui;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.Style;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.AstolfoStyle;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.AugustusStyle;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.BjurStyle;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.BlackStyle;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.JelloStyle;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.LiquidBounceStyle;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.NullStyle;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.Slight.SlightUI;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.SlowlyStyle;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.TenacityStyle;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.WhiteStyle;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.augustus.AugustusClickGUI;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.dropdown.DropdownGUI;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.light.LightClickGUI;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.novoline.ClickyUI;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.onetap.OtcClickGUi;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.tenacity.TenacityClickGUI;
import net.ccbluex.liquidbounce.ui.client.gui.options.modernuiLaunchOption;
import net.ccbluex.liquidbounce.utils.MinecraftInstance;
import net.ccbluex.liquidbounce.utils.render.ColorUtils;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S2EPacketCloseWindow;
import org.jetbrains.annotations.NotNull;

@ModuleInfo(name="ClickGUI", category=ModuleCategory.CLIENT, keyBind=54, canEnable=false)
@Metadata(mv={1, 6, 0}, k=1, xi=48, d1={"\u0000x\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u00c7\u0002\u0018\u00002\u00020\u0001B\u0007\b\u0002\u00a2\u0006\u0002\u0010\u0002J\u0006\u0010;\u001a\u00020<J\b\u0010=\u001a\u00020>H\u0016J\u0010\u0010?\u001a\u00020>2\u0006\u0010@\u001a\u00020AH\u0007J\b\u0010B\u001a\u00020>H\u0002R\u0011\u0010\u0003\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0005\u0010\u0006R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u0010\t\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\r\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u0006R\u000e\u0010\u000f\u001a\u00020\u0010X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u0010\u0011\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\u0015\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0014R\u0011\u0010\u0017\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0014R\u0011\u0010\u0019\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\fR\u0011\u0010\u001b\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0014R\u0011\u0010\u001d\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0006R\u0011\u0010\u001f\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b \u0010\fR\u000e\u0010!\u001a\u00020\"X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u0010#\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b$\u0010\fR\u0011\u0010%\u001a\u00020\n\u00a2\u0006\b\n\u0000\u001a\u0004\b&\u0010\fR\u000e\u0010'\u001a\u00020(X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u0010)\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b*\u0010\u0014R\u000e\u0010+\u001a\u00020,X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010-\u001a\u00020.X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u0010/\u001a\u000200\u00a2\u0006\b\n\u0000\u001a\u0004\b1\u00102R\u0011\u00103\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b4\u0010\u0006R\u000e\u00105\u001a\u000206X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0011\u00107\u001a\u00020\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b8\u0010\u0006R\u000e\u00109\u001a\u00020:X\u0082\u000e\u00a2\u0006\u0002\n\u0000\u00a8\u0006C"}, d2={"Lnet/ccbluex/liquidbounce/ui/client/gui/ClickGUIModule;", "Lnet/ccbluex/liquidbounce/features/module/Module;", "()V", "animationValue", "Lnet/ccbluex/liquidbounce/features/value/ListValue;", "getAnimationValue", "()Lnet/ccbluex/liquidbounce/features/value/ListValue;", "augustusGui", "Lnet/ccbluex/liquidbounce/ui/client/gui/clickgui/style/styles/augustus/AugustusClickGUI;", "backback", "Lnet/ccbluex/liquidbounce/features/value/BoolValue;", "getBackback", "()Lnet/ccbluex/liquidbounce/features/value/BoolValue;", "backgroundValue", "getBackgroundValue", "bjur", "Lnet/ccbluex/liquidbounce/ui/client/gui/clickgui/style/styles/BjurStyle;", "clickHeight", "Lnet/ccbluex/liquidbounce/features/value/IntegerValue;", "getClickHeight", "()Lnet/ccbluex/liquidbounce/features/value/IntegerValue;", "colorBlueValue", "getColorBlueValue", "colorGreenValue", "getColorGreenValue", "colorRainbow", "getColorRainbow", "colorRedValue", "getColorRedValue", "colormode", "getColormode", "disp", "getDisp", "dropdown", "Lnet/ccbluex/liquidbounce/ui/client/gui/clickgui/style/styles/dropdown/DropdownGUI;", "fastRenderValue", "getFastRenderValue", "getClosePrevious", "getGetClosePrevious", "lightClickGUI", "Lnet/ccbluex/liquidbounce/ui/client/gui/clickgui/style/styles/light/LightClickGUI;", "maxElementsValue", "getMaxElementsValue", "novoline", "Lnet/ccbluex/liquidbounce/ui/client/gui/clickgui/style/styles/novoline/ClickyUI;", "otcGui", "Lnet/ccbluex/liquidbounce/ui/client/gui/clickgui/style/styles/onetap/OtcClickGUi;", "scaleValue", "Lnet/ccbluex/liquidbounce/features/value/FloatValue;", "getScaleValue", "()Lnet/ccbluex/liquidbounce/features/value/FloatValue;", "scrollMode", "getScrollMode", "slight", "Lnet/ccbluex/liquidbounce/ui/client/gui/clickgui/style/styles/Slight/SlightUI;", "styleValue", "getStyleValue", "tena", "Lnet/ccbluex/liquidbounce/ui/client/gui/clickgui/style/styles/tenacity/TenacityClickGUI;", "generateColor", "Ljava/awt/Color;", "onEnable", "", "onPacket", "event", "Lnet/ccbluex/liquidbounce/event/PacketEvent;", "updateStyle", "FDPClient"})
public final class ClickGUIModule
extends Module {
    @NotNull
    public static final ClickGUIModule INSTANCE = new ClickGUIModule();
    @NotNull
    private static final ListValue styleValue;
    @NotNull
    private static final BoolValue backback;
    @NotNull
    private static final ListValue scrollMode;
    @NotNull
    private static final ListValue colormode;
    @NotNull
    private static final IntegerValue clickHeight;
    @NotNull
    private static final FloatValue scaleValue;
    @NotNull
    private static final IntegerValue maxElementsValue;
    @NotNull
    private static final ListValue backgroundValue;
    @NotNull
    private static final ListValue animationValue;
    @NotNull
    private static final BoolValue colorRainbow;
    @NotNull
    private static final IntegerValue colorRedValue;
    @NotNull
    private static final IntegerValue colorGreenValue;
    @NotNull
    private static final IntegerValue colorBlueValue;
    @NotNull
    private static final BoolValue fastRenderValue;
    @NotNull
    private static final BoolValue getClosePrevious;
    @NotNull
    private static final BoolValue disp;
    @NotNull
    private static LightClickGUI lightClickGUI;
    @NotNull
    private static OtcClickGUi otcGui;
    @NotNull
    private static ClickyUI novoline;
    @NotNull
    private static SlightUI slight;
    @NotNull
    private static DropdownGUI dropdown;
    @NotNull
    private static TenacityClickGUI tena;
    @NotNull
    private static BjurStyle bjur;
    @NotNull
    private static AugustusClickGUI augustusGui;

    private ClickGUIModule() {
    }

    @NotNull
    public final ListValue getStyleValue() {
        return styleValue;
    }

    @NotNull
    public final BoolValue getBackback() {
        return backback;
    }

    @NotNull
    public final ListValue getScrollMode() {
        return scrollMode;
    }

    @NotNull
    public final ListValue getColormode() {
        return colormode;
    }

    @NotNull
    public final IntegerValue getClickHeight() {
        return clickHeight;
    }

    @NotNull
    public final FloatValue getScaleValue() {
        return scaleValue;
    }

    @NotNull
    public final IntegerValue getMaxElementsValue() {
        return maxElementsValue;
    }

    @NotNull
    public final ListValue getBackgroundValue() {
        return backgroundValue;
    }

    @NotNull
    public final ListValue getAnimationValue() {
        return animationValue;
    }

    @NotNull
    public final BoolValue getColorRainbow() {
        return colorRainbow;
    }

    @NotNull
    public final IntegerValue getColorRedValue() {
        return colorRedValue;
    }

    @NotNull
    public final IntegerValue getColorGreenValue() {
        return colorGreenValue;
    }

    @NotNull
    public final IntegerValue getColorBlueValue() {
        return colorBlueValue;
    }

    @NotNull
    public final BoolValue getFastRenderValue() {
        return fastRenderValue;
    }

    @NotNull
    public final BoolValue getGetClosePrevious() {
        return getClosePrevious;
    }

    @NotNull
    public final BoolValue getDisp() {
        return disp;
    }

    @Override
    public void onEnable() {
        new ResourceMonitor();
        if (StringsKt.contains$default((CharSequence)styleValue.get(), "Novoline", false, 2, null)) {
            MinecraftInstance.mc.func_147108_a((GuiScreen)novoline);
        } else if (StringsKt.contains$default((CharSequence)styleValue.get(), "OneTap", false, 2, null)) {
            MinecraftInstance.mc.func_147108_a((GuiScreen)otcGui);
        } else if (StringsKt.contains$default((CharSequence)styleValue.get(), "Light", false, 2, null)) {
            MinecraftInstance.mc.func_147108_a((GuiScreen)lightClickGUI);
        } else if (StringsKt.equals((String)styleValue.get(), "Classic", true)) {
            MinecraftInstance.mc.func_147108_a((GuiScreen)dropdown);
        } else if (StringsKt.equals((String)styleValue.get(), "Tenacity", true)) {
            MinecraftInstance.mc.func_147108_a((GuiScreen)tena);
        } else if (StringsKt.equals((String)styleValue.get(), "LB+", true)) {
            MinecraftInstance.mc.func_147108_a((GuiScreen)dropdown);
        } else if (StringsKt.equals((String)styleValue.get(), "Bjur", true)) {
            MinecraftInstance.mc.func_147108_a((GuiScreen)bjur);
        } else if (StringsKt.equals((String)styleValue.get(), "Augustus", true)) {
            MinecraftInstance.mc.func_147108_a((GuiScreen)augustusGui);
        } else if (StringsKt.contains$default((CharSequence)styleValue.get(), "Slight", false, 2, null)) {
            MinecraftInstance.mc.func_147108_a((GuiScreen)slight);
        } else {
            this.updateStyle();
            MinecraftInstance.mc.func_147108_a((GuiScreen)modernuiLaunchOption.getClickGui());
        }
        this.setState(false);
    }

    private final void updateStyle() {
        String string = (String)styleValue.get();
        Locale locale = Locale.getDefault();
        Intrinsics.checkNotNullExpressionValue(locale, "getDefault()");
        String string2 = string.toLowerCase(locale);
        Intrinsics.checkNotNullExpressionValue(string2, "this as java.lang.String).toLowerCase(locale)");
        switch (string2) {
            case "liquidbounce": {
                modernuiLaunchOption.getClickGui().style = new LiquidBounceStyle();
                break;
            }
            case "null": {
                modernuiLaunchOption.getClickGui().style = new NullStyle();
                break;
            }
            case "slowly": {
                modernuiLaunchOption.getClickGui().style = new SlowlyStyle();
                break;
            }
            case "white": 
            case "black": {
                modernuiLaunchOption.getClickGui().style = Intrinsics.areEqual(styleValue.get(), "White") ? (Style)new WhiteStyle() : (Style)new BlackStyle();
                break;
            }
            case "jello": {
                modernuiLaunchOption.getClickGui().style = new JelloStyle();
                break;
            }
            case "tenacity5": {
                modernuiLaunchOption.getClickGui().style = new TenacityStyle();
                break;
            }
            case "astolfo": {
                modernuiLaunchOption.getClickGui().style = new AstolfoStyle();
                break;
            }
            case "augustus": {
                modernuiLaunchOption.getClickGui().style = new AugustusStyle();
            }
        }
    }

    @NotNull
    public final Color generateColor() {
        return (Boolean)colorRainbow.get() != false ? ColorUtils.rainbow() : new Color(((Number)colorRedValue.get()).intValue(), ((Number)colorGreenValue.get()).intValue(), ((Number)colorBlueValue.get()).intValue());
    }

    @EventTarget(ignoreCondition=true)
    public final void onPacket(@NotNull PacketEvent event) {
        Intrinsics.checkNotNullParameter(event, "event");
        Packet<?> packet = event.getPacket();
        if (packet instanceof S2EPacketCloseWindow && MinecraftInstance.mc.field_71462_r instanceof ClickGui) {
            event.cancelEvent();
        }
    }

    public static final /* synthetic */ void access$updateStyle(ClickGUIModule $this) {
        $this.updateStyle();
    }

    static {
        String[] stringArray = new String[]{"Classic", "OneTap", "Light", "Novoline", "Astolfo", "LB+", "Jello", "LiquidBounce", "Tenacity5", "Slight", "Bjur", "Null", "Slowly", "Black", "White", "Augustus"};
        String[] stringArray2 = stringArray;
        styleValue = new ListValue(stringArray2){

            protected void onChanged(@NotNull String oldValue, @NotNull String newValue) {
                Intrinsics.checkNotNullParameter(oldValue, "oldValue");
                Intrinsics.checkNotNullParameter(newValue, "newValue");
                ClickGUIModule.access$updateStyle(ClickGUIModule.INSTANCE);
            }
        };
        backback = new BoolValue("Background Accent", true);
        stringArray2 = new String[]{"Screen Height", "Value"};
        scrollMode = new ListValue("Scroll Mode", stringArray2, "Value");
        stringArray2 = new String[]{"White", "Color"};
        colormode = new ListValue("Setting Accent", stringArray2, "Color");
        clickHeight = new IntegerValue("Tab Height", 250, 100, 500);
        scaleValue = new FloatValue("Scale", 0.7f, 0.7f, 2.0f);
        maxElementsValue = new IntegerValue("MaxElements", 20, 1, 35);
        stringArray2 = new String[]{"Default", "Gradient", "None"};
        backgroundValue = new ListValue("Background", stringArray2, "None");
        stringArray2 = new String[]{"Bread", "Slide", "LiquidBounce", "Zoom", "Ziul", "None"};
        animationValue = new ListValue("Animation", stringArray2, "Ziul");
        colorRainbow = new BoolValue("Rainbow", true);
        colorRedValue = (IntegerValue)new IntegerValue("R", 0, 0, 255).displayable(colorRedValue.1.INSTANCE);
        colorGreenValue = (IntegerValue)new IntegerValue("G", 160, 0, 255).displayable(colorGreenValue.1.INSTANCE);
        colorBlueValue = (IntegerValue)new IntegerValue("B", 255, 0, 255).displayable(colorBlueValue.1.INSTANCE);
        fastRenderValue = new BoolValue("FastRender", false);
        getClosePrevious = new BoolValue("ClosePrevious", false);
        disp = new BoolValue("DisplayValue", true);
        lightClickGUI = new LightClickGUI();
        otcGui = new OtcClickGUi();
        novoline = new ClickyUI();
        slight = new SlightUI();
        dropdown = new DropdownGUI();
        tena = new TenacityClickGUI();
        bjur = new BjurStyle();
        augustusGui = new AugustusClickGUI();
    }
}

