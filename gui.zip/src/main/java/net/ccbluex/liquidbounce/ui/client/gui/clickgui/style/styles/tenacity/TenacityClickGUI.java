/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.ResourceLocation
 *  org.lwjgl.input.Mouse
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.tenacity;

import java.util.ArrayList;
import java.util.List;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.fonts.logo.info;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.tenacity.MainScreen;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.tenacity.impl.SettingComponents;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.Animation;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.Direction;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.impl.DecelerateAnimation;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.impl.EaseBackIn;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.normal.Main;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.render.DrRenderUtils;
import net.ccbluex.liquidbounce.ui.client.hud.designer.GuiHudDesigner;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;

public class TenacityClickGUI
extends GuiScreen {
    private Animation openingAnimation;
    private EaseBackIn fadeAnimation;
    private DecelerateAnimation configHover;
    private final ResourceLocation hudIcon = new ResourceLocation("fdpclient/ui/clickgui/hud.png");
    private List<MainScreen> categoryPanels;

    public void func_73866_w_() {
        if (this.categoryPanels == null || Main.reloadModules) {
            this.categoryPanels = new ArrayList(){
                {
                    for (ModuleCategory category : ModuleCategory.values()) {
                        this.add(new MainScreen(category));
                    }
                }
            };
            Main.reloadModules = false;
        }
        info.getInstance().getSideGui().initGui();
        this.fadeAnimation = new EaseBackIn(400, 1.0, 2.0f);
        this.openingAnimation = new EaseBackIn(400, (double)0.4f, 2.0f);
        this.configHover = new DecelerateAnimation(250, 1.0);
        for (MainScreen catPanels : this.categoryPanels) {
            catPanels.animation = this.fadeAnimation;
            catPanels.openingAnimation = this.openingAnimation;
            catPanels.initGui();
        }
    }

    protected void func_73869_a(char typedChar, int keyCode) {
        if (keyCode == 1) {
            this.openingAnimation.setDirection(Direction.BACKWARDS);
            info.getInstance().getSideGui().focused = false;
            this.fadeAnimation.setDirection(this.openingAnimation.getDirection());
        }
        info.getInstance().getSideGui().keyTyped(typedChar, keyCode);
        this.categoryPanels.forEach(categoryPanel -> categoryPanel.keyTyped(typedChar, keyCode));
    }

    public boolean func_73868_f() {
        return false;
    }

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        if (Mouse.isButtonDown((int)0) && mouseX >= 5 && mouseX <= 50 && mouseY <= this.field_146295_m - 5 && mouseY >= this.field_146295_m - 50) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiHudDesigner());
        }
        RenderUtils.drawImage(this.hudIcon, 9, this.field_146295_m - 41, 32, 32);
        if (Main.reloadModules) {
            this.func_73866_w_();
        }
        if (this.openingAnimation.isDone() && this.openingAnimation.getDirection().equals((Object)Direction.BACKWARDS)) {
            this.field_146297_k.func_147108_a(null);
            return;
        }
        boolean focusedConfigGui = info.getInstance().getSideGui().focused;
        int fakeMouseX = focusedConfigGui ? 0 : mouseX;
        int fakeMouseY = focusedConfigGui ? 0 : mouseY;
        ScaledResolution sr = new ScaledResolution(this.field_146297_k);
        boolean hoveringConfig = DrRenderUtils.isHovering(this.field_146294_l - 120, this.field_146295_m - 65, 75.0f, 25.0f, fakeMouseX, fakeMouseY);
        this.configHover.setDirection(hoveringConfig ? Direction.FORWARDS : Direction.BACKWARDS);
        int alphaAnimation = Math.max(0, Math.min(255, (int)(255.0 * this.fadeAnimation.getOutput())));
        GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        SettingComponents.scale = (float)(this.openingAnimation.getOutput() + (double)0.6f);
        DrRenderUtils.scale((float)sr.func_78326_a() / 2.0f, (float)sr.func_78328_b() / 2.0f, (float)this.openingAnimation.getOutput() + 0.6f, () -> {
            for (MainScreen catPanels : this.categoryPanels) {
                catPanels.drawScreen(fakeMouseX, fakeMouseY);
            }
            info.getInstance().getSideGui().drawScreen(mouseX, mouseY, partialTicks, alphaAnimation);
        });
    }

    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) {
        boolean focused = info.getInstance().getSideGui().focused;
        info.getInstance().getSideGui().mouseClicked(mouseX, mouseY, mouseButton);
        if (!focused) {
            this.categoryPanels.forEach(cat -> cat.mouseClicked(mouseX, mouseY, mouseButton));
        }
    }

    protected void func_146286_b(int mouseX, int mouseY, int state) {
        boolean focused = info.getInstance().getSideGui().focused;
        info.getInstance().getSideGui().mouseReleased(mouseX, mouseY, state);
        if (!focused) {
            this.categoryPanels.forEach(cat -> cat.mouseReleased(mouseX, mouseY, state));
        }
    }
}

