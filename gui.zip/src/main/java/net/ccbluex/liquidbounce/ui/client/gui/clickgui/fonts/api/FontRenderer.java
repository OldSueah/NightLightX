/*
 * Decompiled with CFR 0.152.
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui.fonts.api;

public interface FontRenderer {
    public float drawString(CharSequence var1, float var2, float var3, int var4, boolean var5);

    public String trimStringToWidth(CharSequence var1, int var2, boolean var3);

    public int stringWidth(CharSequence var1);

    public int getHeight();

    default public float drawString(CharSequence text, float x, float y, int color) {
        return this.drawString(text, x, y, color, false);
    }

    default public void drawString(CharSequence text, int x, int y, int color) {
        this.drawString(text, x, y, color, false);
    }

    default public String trimStringToWidth(CharSequence text, int width) {
        return this.trimStringToWidth(text, width, false);
    }

    default public float drawCenteredString(CharSequence text, float x, float y, int color, boolean dropShadow) {
        return this.drawString(text, x - (float)this.stringWidth(text) / 2.0f, y, color, dropShadow);
    }

    default public float getMiddleOfBox(float boxHeight) {
        return boxHeight / 2.0f - (float)this.getHeight() / 2.0f;
    }

    default public void drawCenteredString(CharSequence text, float x, float y, int color) {
        this.drawCenteredString(text, x, y, color, false);
    }
}

