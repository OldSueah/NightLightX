/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.ScaledResolution
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.tenacity;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import net.ccbluex.liquidbounce.FDPClient;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.ui.client.gui.ClickGUIModule;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.fonts.impl.Fonts;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.tenacity.impl.ModuleRect;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.Animation;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.Direction;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.impl.DecelerateAnimation;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.normal.Main;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.normal.Screen;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.render.DrRenderUtils;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.render.StencilUtil;
import net.ccbluex.liquidbounce.utils.MathUtils;
import net.minecraft.client.gui.ScaledResolution;

public class MainScreen
implements Screen {
    private final ModuleCategory category;
    private final float rectWidth = 110.0f;
    private final float categoryRectHeight = 18.0f;
    public Animation animation;
    public HashMap<ModuleRect, Animation> moduleAnimMap = new HashMap();
    public Animation openingAnimation;
    private List<ModuleRect> moduleRects;

    public MainScreen(ModuleCategory category) {
        this.category = category;
    }

    @Override
    public void initGui() {
        if (this.moduleRects == null) {
            this.moduleRects = new ArrayList<ModuleRect>();
            for (Module module : Main.getModulesInCategory(this.category, FDPClient.moduleManager).stream().sorted(Comparator.comparing(Module::getName)).collect(Collectors.toList())) {
                ModuleRect moduleRect = new ModuleRect(module);
                this.moduleRects.add(moduleRect);
                this.moduleAnimMap.put(moduleRect, new DecelerateAnimation(250, 1.0));
            }
        }
        if (this.moduleRects != null) {
            this.moduleRects.forEach(ModuleRect::initGui);
        }
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (this.moduleRects != null) {
            this.moduleRects.forEach(moduleRect -> moduleRect.keyTyped(typedChar, keyCode));
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        float animClamp = (float)Math.max(0.0, Math.min(255.0, 255.0 * this.animation.getOutput()));
        int alphaAnimation = (int)animClamp;
        int categoryRectColor = new Color(29, 29, 29, alphaAnimation).getRGB();
        int textColor = new Color(255, 255, 255, alphaAnimation).getRGB();
        this.category.getDrag().onDraw(mouseX, mouseY);
        float x = this.category.getDrag().getX();
        float y = this.category.getDrag().getY();
        DrRenderUtils.drawRect2(x, y, 110.0, 18.0, categoryRectColor);
        DrRenderUtils.setAlphaLimit(0.0f);
        Fonts.SFBOLD.SFBOLD_26.SFBOLD_26.drawString((CharSequence)this.category.name(), x + 5.0f, y + Fonts.SFBOLD.SFBOLD_26.SFBOLD_26.getMiddleOfBox(18.0f), textColor);
        String l = "";
        if (this.category.name().equalsIgnoreCase("Combat")) {
            l = "D";
        } else if (this.category.name().equalsIgnoreCase("Movement")) {
            l = "A";
        } else if (this.category.name().equalsIgnoreCase("Player")) {
            l = "B";
        } else if (this.category.name().equalsIgnoreCase("Render")) {
            l = "C";
        } else if (this.category.name().equalsIgnoreCase("Exploit")) {
            l = "G";
        } else if (this.category.name().equalsIgnoreCase("Misc")) {
            l = "F";
        }
        DrRenderUtils.setAlphaLimit(0.0f);
        DrRenderUtils.resetColor();
        Fonts.ICONFONT.ICONFONT_20.ICONFONT_20.drawString((CharSequence)l, x + 110.0f - (float)(Fonts.ICONFONT.ICONFONT_20.ICONFONT_20.stringWidth(l) + 5), y + Fonts.ICONFONT.ICONFONT_20.ICONFONT_20.getMiddleOfBox(18.0f), textColor);
        if (this.category.name().equalsIgnoreCase("World")) {
            Fonts.CheckFont.CheckFont_20.CheckFont_20.drawString((CharSequence)"b", x + 110.0f - (float)(Fonts.CheckFont.CheckFont_20.CheckFont_20.stringWidth("b") + 5), y + Fonts.ICONFONT.ICONFONT_20.ICONFONT_20.getMiddleOfBox(18.0f), textColor);
        }
        if (ClickGUIModule.INSTANCE.getScrollMode().equals("Value")) {
            Main.allowedClickGuiHeight = ((Integer)ClickGUIModule.INSTANCE.getClickHeight().get()).floatValue();
        } else {
            ScaledResolution sr = new ScaledResolution(mc);
            Main.allowedClickGuiHeight = (float)(2 * sr.func_78328_b()) / 3.0f;
        }
        float allowedHeight = Main.allowedClickGuiHeight;
        boolean hoveringMods = DrRenderUtils.isHovering(x, y + 18.0f, 110.0f, allowedHeight, mouseX, mouseY);
        float scaleAnim = Math.max(1.0f, (float)this.openingAnimation.getOutput() + 0.7f);
        float width = 110.0f;
        StencilUtil.initStencilToWrite();
        DrRenderUtils.drawRect2(x - 100.0f, y + 18.0f, 260.0, allowedHeight, -1);
        StencilUtil.readStencilBuffer(1);
        double scroll = this.category.getScroll().getScroll();
        double count = 0.0;
        for (ModuleRect moduleRect : this.moduleRects) {
            Animation animation = this.moduleAnimMap.get(moduleRect);
            animation.setDirection(moduleRect.module.getExpanded() ? Direction.FORWARDS : Direction.BACKWARDS);
            moduleRect.settingAnimation = animation;
            moduleRect.alphaAnimation = alphaAnimation;
            moduleRect.x = x;
            moduleRect.height = 17.0f;
            moduleRect.panelLimitY = y;
            moduleRect.openingAnimation = this.openingAnimation;
            moduleRect.y = (float)((double)(y + 18.0f) + count * 17.0 + MathUtils.INSTANCE.roundToHalf(scroll));
            moduleRect.width = 110.0f;
            moduleRect.drawScreen(mouseX, mouseY);
            count += 1.0 + moduleRect.getSettingSize();
        }
        if (hoveringMods) {
            this.category.getScroll().onScroll(30);
            float hiddenHeight = (float)(count * 17.0 - (double)allowedHeight);
            this.category.getScroll().setMinScroll(Math.max(0.0f, hiddenHeight));
        }
        StencilUtil.uninitStencilBuffer();
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        boolean canDrag = DrRenderUtils.isHovering(this.category.getDrag().getX(), this.category.getDrag().getY(), 110.0f, 18.0f, mouseX, mouseY);
        this.category.getDrag().onClick(mouseX, mouseY, button, canDrag);
        this.moduleRects.forEach(moduleRect -> moduleRect.mouseClicked(mouseX, mouseY, button));
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        this.category.getDrag().onRelease(state);
        this.moduleRects.forEach(moduleRect -> moduleRect.mouseReleased(mouseX, mouseY, state));
    }
}

