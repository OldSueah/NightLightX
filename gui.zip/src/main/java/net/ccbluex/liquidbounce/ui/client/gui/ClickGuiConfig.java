/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  com.google.gson.JsonElement
 *  com.google.gson.JsonNull
 *  com.google.gson.JsonObject
 *  com.google.gson.JsonParser
 */
package net.ccbluex.liquidbounce.ui.client.gui;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.File;
import net.ccbluex.liquidbounce.file.FileConfig;
import net.ccbluex.liquidbounce.file.FileManager;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.Panel;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.elements.Element;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.elements.ModuleElement;
import net.ccbluex.liquidbounce.ui.client.gui.options.modernuiLaunchOption;
import net.ccbluex.liquidbounce.utils.ClientUtils;

public class ClickGuiConfig
extends FileConfig {
    public ClickGuiConfig(File file) {
        super(file);
    }

    @Override
    public void loadConfig(String config) {
        JsonElement jsonElement = new JsonParser().parse(config);
        if (jsonElement instanceof JsonNull) {
            return;
        }
        JsonObject jsonObject = (JsonObject)jsonElement;
        for (Panel panel : modernuiLaunchOption.clickGui.panels) {
            if (!jsonObject.has(panel.getCategory().getConfigName())) continue;
            try {
                JsonObject panelObject = jsonObject.getAsJsonObject(panel.getCategory().getConfigName());
                panel.setOpen(panelObject.get("open").getAsBoolean());
                panel.setVisible(panelObject.get("visible").getAsBoolean());
                panel.setX(panelObject.get("posX").getAsInt());
                panel.setY(panelObject.get("posY").getAsInt());
                for (Element element : panel.getElements()) {
                    ModuleElement moduleElement;
                    if (!(element instanceof ModuleElement) || !panelObject.has((moduleElement = (ModuleElement)element).getModule().getName())) continue;
                    try {
                        JsonObject elementObject = panelObject.getAsJsonObject(moduleElement.getModule().getName());
                        moduleElement.setShowSettings(elementObject.get("Settings").getAsBoolean());
                    }
                    catch (Exception e) {
                        ClientUtils.INSTANCE.logError("Error while loading clickgui module element with the name '" + moduleElement.getModule().getName() + "' (Panel Name: " + panel.getCategory().getConfigName() + ").", e);
                    }
                }
            }
            catch (Exception e) {
                ClientUtils.INSTANCE.logError("Error while loading clickgui panel with the name '" + panel.getCategory().getConfigName() + "'.", e);
            }
        }
    }

    @Override
    public String saveConfig() {
        JsonObject jsonObject = new JsonObject();
        for (Panel panel : modernuiLaunchOption.clickGui.panels) {
            JsonObject panelObject = new JsonObject();
            panelObject.addProperty("open", Boolean.valueOf(panel.getOpen()));
            panelObject.addProperty("visible", Boolean.valueOf(panel.isVisible()));
            panelObject.addProperty("posX", (Number)panel.getX());
            panelObject.addProperty("posY", (Number)panel.getY());
            for (Element element : panel.getElements()) {
                if (!(element instanceof ModuleElement)) continue;
                ModuleElement moduleElement = (ModuleElement)element;
                JsonObject elementObject = new JsonObject();
                elementObject.addProperty("Settings", Boolean.valueOf(moduleElement.isShowSettings()));
                panelObject.add(moduleElement.getModule().getName(), (JsonElement)elementObject);
            }
            jsonObject.add(panel.getCategory().getConfigName(), (JsonElement)panelObject);
        }
        return FileManager.Companion.getPRETTY_GSON().toJson((JsonElement)jsonObject);
    }
}

