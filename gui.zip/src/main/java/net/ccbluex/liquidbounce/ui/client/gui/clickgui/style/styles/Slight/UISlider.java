/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.ScaledResolution
 *  org.lwjgl.input.Mouse
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.Slight;

import java.awt.Color;
import net.ccbluex.liquidbounce.features.value.FloatValue;
import net.ccbluex.liquidbounce.features.value.IntegerValue;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.Slight.RenderUtil;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.ui.font.GameFontRenderer;
import net.ccbluex.liquidbounce.utils.render.Colors;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Mouse;

public class UISlider {
    FloatValue value;
    IntegerValue valuee;
    public float x;
    public float y;
    public int x2;
    public int y2;
    private boolean isDraging;
    private boolean clickNotDraging;
    public boolean showValue;
    public int tX;
    public int tY;
    public int dragX;
    public int dragY;
    float ani = 0.0f;
    float aniH;

    public UISlider(FloatValue value) {
        this.value = value;
    }

    public UISlider(IntegerValue valuee) {
        this.valuee = valuee;
    }

    public static Color rainbow(long time, float count, float fade) {
        float hue = ((float)time + (1.0E-9f + count) * 4.0E8f) / 1.75E10f * 3.0f;
        long color = Long.parseLong(Integer.toHexString(Color.HSBtoRGB(hue, 0.5f, 1.0f)), 16);
        Color c = new Color((int)color);
        return new Color((float)c.getRed() / 255.0f * fade, (float)c.getGreen() / 255.0f * fade, (float)c.getBlue() / 255.0f * fade, (float)c.getAlpha() / 255.0f);
    }

    public void draw(float x, float y) {
        boolean countMod = false;
        int[] counter = new int[1];
        int rainbowCol = UISlider.rainbow(System.nanoTime() * 3L, counter[0], 1.0f).getRGB();
        Color col = new Color(rainbowCol);
        int Ranbow = new Color(0, col.getGreen() / 3 + 40, col.getGreen() / 2 + 100).getRGB();
        int Ranbow1 = new Color(0, col.getGreen() / 3 + 20, col.getGreen() / 2 + 100).getRGB();
        GameFontRenderer tahoma20 = Fonts.font35;
        float n = (((Float)this.value.getValue()).floatValue() - this.value.getMinimum()) / (this.value.getMaximum() - this.value.getMinimum());
        tahoma20.drawString(this.value.getName(), x - 75.0f, y - 3.0f, Colors.WHITE.c);
        Fonts.font35.drawString(this.value.getValue() + "", x + 250.0f - (float)Fonts.font35.func_78256_a(this.value.getValue() + ""), y - 1.0f, new Color(Colors.GREY.c).brighter().brighter().getRGB());
        if (this.ani == 0.0f) {
            this.ani = (float)((double)(x + 250.0f) - (370.0 - 370.0 * (double)n));
        }
        this.ani = (float)RenderUtil.getAnimationState(this.ani, (float)((double)(x + 250.0f) - (370.0 - 370.0 * (double)n)), (float)Math.max(10.0, Math.abs((double)this.ani - ((double)(x + 120.0f) - (370.0 - 370.0 * (double)n))) * 30.0 * 0.3));
        if (this.showValue) {
            // empty if block
        }
        RenderUtil.drawRect(x - 75.0f, y + 3.0f + 11.0f, x + 250.0f, y + 4.0f + 11.0f, new Color(60, 60, 60).getRGB());
        RenderUtil.drawGradientRect2(x - 75.0f, y + 3.0f + 11.0f, this.ani, y + 4.0f + 11.0f, Ranbow, new Color(4555775).getRGB());
    }

    public void draww(float x, float y) {
        boolean countMod = false;
        int[] counter = new int[1];
        int rainbowCol = UISlider.rainbow(System.nanoTime() * 3L, counter[0], 1.0f).getRGB();
        Color col = new Color(rainbowCol);
        int Ranbow = new Color(0, col.getGreen() / 3 + 40, col.getGreen() / 2 + 100).getRGB();
        int Ranbow1 = new Color(0, col.getGreen() / 3 + 20, col.getGreen() / 2 + 100).getRGB();
        GameFontRenderer tahoma20 = Fonts.font35;
        int n = ((Integer)this.valuee.getValue() - this.valuee.getMinimum()) / (this.valuee.getMaximum() - this.valuee.getMinimum());
        tahoma20.drawString(this.valuee.getName(), x - 75.0f, y - 3.0f, Colors.WHITE.c);
        Fonts.font35.drawString(this.valuee.getValue() + "", x + 250.0f - (float)Fonts.font35.func_78256_a(this.valuee.getValue() + ""), y - 1.0f, new Color(Colors.GREY.c).brighter().brighter().getRGB());
        if (this.ani == 0.0f) {
            this.ani = (float)((double)(x + 250.0f) - (370.0 - 370.0 * (double)n));
        }
        this.ani = (float)RenderUtil.getAnimationState(this.ani, (float)((double)(x + 250.0f) - (370.0 - 370.0 * (double)n)), (float)Math.max(10.0, Math.abs((double)this.ani - ((double)(x + 120.0f) - (370.0 - 370.0 * (double)n))) * 30.0 * 0.3));
        if (this.showValue) {
            // empty if block
        }
        RenderUtil.drawRect(x - 75.0f, y + 3.0f + 11.0f, x + 250.0f, y + 4.0f + 11.0f, new Color(60, 60, 60).getRGB());
        RenderUtil.drawGradientRect2(x - 75.0f, y + 3.0f + 11.0f, this.ani, y + 4.0f + 11.0f, Ranbow, new Color(4555775).getRGB());
    }

    public void drawAll(float x, float y, int tx, int ty) {
        this.x = x;
        this.y = y;
        new ScaledResolution(Minecraft.func_71410_x());
        this.showValue = this.isHovered(tx, ty, this.x - 100.0f, this.y - 3.0f + 11.0f, this.x - 10.0f, this.y + 10.0f + 11.0f);
        if (Mouse.isButtonDown((int)0)) {
            if (!this.isHovered(tx, ty, this.x - 75.0f, this.y - 3.0f + 11.0f, this.x + 250.0f, this.y + 10.0f + 11.0f) && !this.isDraging) {
                this.clickNotDraging = true;
            } else {
                this.isDraging = true;
            }
            if (this.isDraging && !this.clickNotDraging) {
                float n = ((float)tx - this.x + 120.0f) / 370.0f;
                if ((double)n < 0.0) {
                    n = 0.0f;
                }
                if ((double)n > 1.0) {
                    n = 1.0f;
                }
                float n2 = (float)Math.round(this.value.getMaximum() - this.value.getMinimum()) * n + this.value.getMinimum() * 100.0f / 100.0f;
                this.value.set(Float.valueOf(n2));
            }
        } else {
            this.isDraging = false;
            this.clickNotDraging = false;
        }
        this.tX = tx;
        this.tY = ty;
        this.draw(x, y);
    }

    public void drawAlll(float x, float y, int tx, int ty) {
        this.x = x;
        this.y = y;
        new ScaledResolution(Minecraft.func_71410_x());
        this.showValue = this.isHovered(tx, ty, this.x - 100.0f, this.y - 3.0f + 11.0f, this.x - 10.0f, this.y + 10.0f + 11.0f);
        if (Mouse.isButtonDown((int)0)) {
            if (!this.isHovered(tx, ty, this.x - 75.0f, this.y - 3.0f + 11.0f, this.x + 250.0f, this.y + 10.0f + 11.0f) && !this.isDraging) {
                this.clickNotDraging = true;
            } else {
                this.isDraging = true;
            }
            if (this.isDraging && !this.clickNotDraging) {
                int n = (tx - this.x2 + 120) / 370;
                if (n < 0) {
                    n = 0;
                }
                if (n > 1) {
                    n = 1;
                }
                int n2 = (int)((double)(Math.round(this.valuee.getMaximum() - this.valuee.getMinimum()) * n) + (double)this.valuee.getMinimum() * 1.0 / 1.0);
                this.valuee.set(n2);
            }
        } else {
            this.isDraging = false;
            this.clickNotDraging = false;
        }
        this.tX = tx;
        this.tY = ty;
        this.draww(x, y);
    }

    public boolean isHovered(int mouseX, int mouseY, float x, float y, float x2, float y2) {
        return (float)mouseX >= x && (float)mouseX <= x2 && (float)mouseY >= y && (float)mouseY <= y2;
    }
}

