/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.Gui
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.GuiYesNoCallback
 *  net.minecraft.client.gui.ScaledResolution
 *  net.minecraft.util.ResourceLocation
 *  org.lwjgl.input.Mouse
 *  org.lwjgl.opengl.GL11
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.Slight;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import net.ccbluex.liquidbounce.FDPClient;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.value.BoolValue;
import net.ccbluex.liquidbounce.features.value.FloatValue;
import net.ccbluex.liquidbounce.features.value.IntegerValue;
import net.ccbluex.liquidbounce.features.value.ListValue;
import net.ccbluex.liquidbounce.features.value.Value;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.Slight.Opacity;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.Slight.RenderUtil;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.Slight.UISlider;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.ui.font.GameFontRenderer;
import net.ccbluex.liquidbounce.utils.render.Colors;
import net.ccbluex.liquidbounce.utils.timer.TimerUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiYesNoCallback;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class SlightUI
extends GuiScreen
implements GuiYesNoCallback {
    public static ModuleCategory currentModuleType = ModuleCategory.COMBAT;
    public static Module currentModule = FDPClient.moduleManager.getModuleInCategory(currentModuleType).get(0);
    public static float startX = 100.0f;
    public static float startY = 85.0f;
    public float moduleStart = 0.0f;
    public int valueStart = 0;
    boolean previousmouse = true;
    boolean mouse;
    boolean MIND = false;
    public Opacity opacity = new Opacity(0);
    public int opacityx = 255;
    public float animationopacity = 0.0f;
    public float animationMN = 0.0f;
    public float animationX = 0.0f;
    public float animationY = 0.0f;
    public float moveX = 0.0f;
    public float moveY = 0.0f;
    private Color buttonColor = new Color(0, 0, 0);
    public GameFontRenderer LogoFont = Fonts.fontSFUI35;
    boolean bind = false;
    TimerUtils AnimationTimer = new TimerUtils();
    private boolean isDraging;
    private boolean clickNotDraging;
    float animationDWheel;
    int finheight;
    float animheight = 0.0f;
    public ArrayList modBooleanValue = new ArrayList();
    public ArrayList modModeValue = new ArrayList();
    public ArrayList modDoubleValue = new ArrayList();
    public ArrayList modIntValue = new ArrayList();
    public static Map doubleValueMap = new HashMap();
    public static Map IntValueMap = new HashMap();

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        int m;
        if (this.isHovered(startX - 10.0f, startY - 40.0f, startX + 280.0f, startY + 25.0f, mouseX, mouseY) && Mouse.isButtonDown((int)0)) {
            if (this.moveX == 0.0f && this.moveY == 0.0f) {
                this.moveX = (float)mouseX - startX;
                this.moveY = (float)mouseY - startY;
            } else {
                startX = (float)mouseX - this.moveX;
                startY = (float)mouseY - this.moveY;
            }
            this.previousmouse = true;
        } else if (this.moveX != 0.0f || this.moveY != 0.0f) {
            this.moveX = 0.0f;
            this.moveY = 0.0f;
        }
        float scale = 1.0f;
        ScaledResolution sr = new ScaledResolution(this.field_146297_k);
        scale = sr.func_78328_b() > 420 && sr.func_78326_a() > 570 ? 1.0f : 0.8f;
        RenderUtil.drawImage(new ResourceLocation("fdpclient/ui/clickgui/slight/background.png"), 0, 0, (int)((float)sr.func_78326_a() * (1.0f / scale)), (int)((float)sr.func_78328_b() * (1.0f / scale)));
        this.opacity.interpolate(this.opacityx);
        boolean countMod = false;
        int[] counter = new int[1];
        int rainbowCol = UISlider.rainbow(System.nanoTime() * 3L, counter[0], 1.0f).getRGB();
        Color col = new Color(rainbowCol);
        int Ranbow = new Color(0, col.getGreen() / 3 + 40, col.getGreen() / 2 + 100).getRGB();
        int Ranbow1 = new Color(0, col.getGreen() / 4 + 20, col.getGreen() / 2 + 100).getRGB();
        RenderUtil.drawDimRect(startX - 40.0f, startY - 10.0f, startX + 300.0f, startY + 260.0f, Colors.getColor(32, 32, 32));
        RenderUtil.drawGradientRect2(startX - 40.0f, startY - 12.0f, startX + 300.0f, startY - 10.0f, Ranbow, new Color(4555775).getRGB());
        RenderUtil.drawRect(startX + 65.0f, startY + 25.0f, startX + 165.0f, startY + 30.0f, new Color(25, 145, 220).getRGB());
        for (m = 0; m < ModuleCategory.values().length; ++m) {
            ModuleCategory[] mY = ModuleCategory.values();
            if (mY[m] == currentModuleType) {
                this.finheight = m * 30;
                RenderUtil.drawGradientRect2(startX - 30.0f, startY + 30.0f + this.animheight, startX - 29.0f, startY + 40.0f + this.animheight, Ranbow, new Color(4555775).getRGB());
                this.animheight = (float)RenderUtil.getAnimationState(this.animheight, this.finheight, Math.max(100.0f, Math.abs((float)this.finheight - this.animheight) * 10.0f));
                if (this.animheight == (float)this.finheight) {
                    Fonts.fontSFUI35.drawString(mY[m].name(), startX - 25.0f, startY + 30.0f + (float)(m * 30), new Color(255, 255, 255).getRGB());
                } else {
                    Fonts.fontSFUI35.drawString(mY[m].name(), startX - 25.0f, startY + 30.0f + (float)(m * 30), new Color(196, 196, 196).getRGB());
                }
            } else {
                RenderUtil.drawRect(startX - 25.0f, startY + 50.0f + (float)(m * 30), startX + 60.0f, startY + 75.0f + (float)(m * 30), new Color(255, 255, 255, 0).getRGB());
                Fonts.fontSFUI35.drawString(mY[m].name(), startX - 25.0f, startY + 30.0f + (float)(m * 30), new Color(196, 196, 196).getRGB());
            }
            try {
                if (!this.isCategoryHovered(startX - 40.0f, startY + 20.0f + (float)(m * 30), startX + 60.0f, startY + 45.0f + (float)(m * 40), mouseX, mouseY) || !Mouse.isButtonDown((int)0) || this.MIND) continue;
                currentModuleType = mY[m];
                currentModule = FDPClient.moduleManager.getModuleInCategory(currentModuleType).size() != 0 ? FDPClient.moduleManager.getModuleInCategory(currentModuleType).get(0) : null;
                this.moduleStart = 0.0f;
                continue;
            }
            catch (Exception exception) {
                System.err.println(exception);
            }
        }
        m = Mouse.getDWheel();
        if (this.isCategoryHovered(startX + 60.0f, startY, startX + 200.0f, startY + 235.0f, mouseX, mouseY) && !this.MIND) {
            if (m < 0 && this.moduleStart < (float)(FDPClient.moduleManager.getModuleInCategory(currentModuleType).size() - 1)) {
                this.moduleStart += 1.0f;
                this.animationDWheel = (float)RenderUtil.getAnimationState(this.animationDWheel, 1.0, 50.0);
                Minecraft.func_71410_x().field_71439_g.func_85030_a("random.click", 0.2f, 2.0f);
            }
            if (m > 0 && this.moduleStart > 0.0f) {
                this.moduleStart -= 1.0f;
                this.moduleStart = (float)RenderUtil.getAnimationState(this.moduleStart, -1.0, 50.0);
                Minecraft.func_71410_x().field_71439_g.func_85030_a("random.click", 0.2f, 2.0f);
            }
        } else {
            this.animationDWheel = 0.0f;
        }
        if (this.isCategoryHovered(startX - 40.0f, startY - 10.0f, startX + 300.0f, startY + 240.0f, mouseX, mouseY) && this.MIND) {
            if (m < 0 && this.valueStart < currentModule.getValues().size() - 1) {
                ++this.valueStart;
            }
            if (m > 0 && this.valueStart > 0) {
                --this.valueStart;
            }
        }
        if (currentModule != null) {
            Value<?> value;
            int font;
            this.modBooleanValue.clear();
            this.modModeValue.clear();
            this.modDoubleValue.clear();
            this.modIntValue.clear();
            float f = startY + 30.0f;
            for (font = 0; font < FDPClient.moduleManager.getModuleInCategory(currentModuleType).size(); ++font) {
                value = FDPClient.moduleManager.getModuleInCategory(currentModuleType).get(font);
                if (f > startY + 220.0f) break;
                if (!((float)font >= this.moduleStart)) continue;
                RenderUtil.drawRect(startX + 75.0f, f, startX + 185.0f, f + 2.0f, new Color(246, 246, 246, 100).getRGB());
                if (!((Module)((Object)value)).getState()) {
                    RenderUtil.drawDimRect(startX + 50.0f, f - 5.0f, startX + 285.0f, f + 20.0f, new Color(38, 38, 37).getRGB());
                    if (currentModule.getValues().size() > 0) {
                        RenderUtil.drawDimRect(startX + 270.0f, f - 5.0f, startX + 285.0f, f + 20.0f, new Color(44, 44, 45).getRGB());
                        RenderUtil.circle(startX + 277.0f, f + 2.0f, 0.7f, new Color(95, 95, 95));
                        RenderUtil.circle(startX + 277.0f, f + 7.0f, 0.7f, new Color(95, 95, 95));
                        RenderUtil.circle(startX + 277.0f, f + 12.0f, 0.7f, new Color(95, 95, 95));
                    }
                } else {
                    RenderUtil.drawDimRect(startX + 50.0f, f - 5.0f, startX + 285.0f, f + 20.0f, new Color(55, 55, 55).getRGB());
                }
                if (this.isSettingsButtonHovered(startX + 65.0f, f, startX + 285.0f, f + 8.0f + (float)Fonts.fontSFUI35.func_78256_a(""), mouseX, mouseY) && !this.MIND) {
                    this.animationopacity = (float)RenderUtil.getAnimationState(this.animationopacity, 0.3f, 20.0);
                    this.animationMN = (float)RenderUtil.getAnimationState(this.animationMN, 10.0, 100.0);
                    if (!((Module)((Object)value)).getState()) {
                        Fonts.fontSFUI35.func_175065_a(((Module)((Object)value)).getName(), startX + 70.0f + this.animationMN, f + 4.0f, new Color(240, 240, 240).getRGB(), false);
                    } else {
                        Fonts.fontSFUI35.func_175065_a(((Module)((Object)value)).getName(), startX + 70.0f + this.animationMN, f + 4.0f, new Color(255, 255, 255).getRGB(), false);
                    }
                } else {
                    this.animationopacity = (float)RenderUtil.getAnimationState(this.animationopacity, 0.0, 20.0);
                    this.animationMN = (float)RenderUtil.getAnimationState(this.animationMN, 0.0, 100.0);
                    if (((Module)((Object)value)).getState()) {
                        Fonts.fontSFUI35.func_175065_a(((Module)((Object)value)).getName(), startX + 70.0f + this.animationMN, f + 4.0f, new Color(200, 200, 200).getRGB(), false);
                    } else {
                        Fonts.fontSFUI35.func_175065_a(((Module)((Object)value)).getName(), startX + 70.0f + this.animationMN, f + 4.0f, new Color(190, 190, 190).getRGB(), false);
                    }
                }
                RenderUtil.drawRect(startX + 50.0f, f - 5.0f, startX + 285.0f, f + 20.0f, RenderUtil.reAlpha(Colors.WHITE.c, this.animationopacity));
                if (((Module)((Object)value)).getState()) {
                    RenderUtil.drawGradientRect2(startX + 50.0f, f - 5.0f, startX + 51.0f, f + 20.0f, Ranbow, new Color(4555775).getRGB());
                }
                if (this.isSettingsButtonHovered(startX + 65.0f, f, startX + 285.0f, f + 8.0f + (float)Fonts.fontSFUI35.func_78256_a(""), mouseX, mouseY) && !this.MIND) {
                    if (!this.previousmouse && Mouse.isButtonDown((int)0)) {
                        if (((Module)((Object)value)).getState()) {
                            ((Module)((Object)value)).setState(false);
                        } else {
                            ((Module)((Object)value)).setState(true);
                        }
                        this.previousmouse = true;
                    }
                    if (!this.previousmouse && Mouse.isButtonDown((int)1)) {
                        this.previousmouse = true;
                    }
                }
                if (!Mouse.isButtonDown((int)0) && !this.MIND) {
                    this.previousmouse = false;
                }
                if (this.isSettingsButtonHovered(startX + 65.0f, f, startX + 285.0f + (float)Fonts.fontSFUI35.func_78256_a(((Module)((Object)value)).getName()), f + 8.0f + (float)Fonts.fontSFUI35.func_78256_a(""), mouseX, mouseY) && Mouse.isButtonDown((int)1) && !this.MIND) {
                    currentModule = value;
                    Minecraft.func_71410_x().field_71439_g.func_85030_a("random.click", 0.5f, 4.0f);
                    this.valueStart = 0;
                    this.MIND = true;
                }
                f += 30.0f;
            }
            for (font = 0; font < currentModule.getValues().size(); ++font) {
                value = currentModule.getValues().get(font);
                if (value instanceof BoolValue) {
                    this.modBooleanValue.add((BoolValue)value);
                }
                if (value instanceof ListValue) {
                    this.modModeValue.add((ListValue)value);
                }
                if (value instanceof FloatValue) {
                    this.modDoubleValue.add((FloatValue)value);
                }
                if (!(value instanceof IntegerValue)) continue;
                this.modIntValue.add((IntegerValue)value);
            }
            f = startY + 12.0f;
            if (this.MIND) {
                UISlider uislider;
                float x;
                if (this.isCategoryHovered(startX - 40.0f, startY - 10.0f, startX + 300.0f, startY + 240.0f, mouseX, mouseY)) {
                    if (m < 0 && this.valueStart < (currentModule.getValues().size() - 1) * 12) {
                        this.valueStart += 12;
                    }
                    if (m > 0 && this.valueStart - 12 >= 0) {
                        this.valueStart -= 12;
                    } else if (m > 0) {
                        this.valueStart = 0;
                    }
                }
                if (this.animationX == 0.0f) {
                    // empty if block
                }
                this.animationX = (float)RenderUtil.getAnimationState(this.animationX, 390.0, 600.0);
                this.animationY = (float)RenderUtil.getAnimationState(this.animationY, 120.0, 800.0);
                GL11.glPushMatrix();
                GL11.glEnable((int)3089);
                RenderUtil.doGlScissor((int)(startX - 40.0f), 0, (int)this.animationX, RenderUtil.height());
                RenderUtil.drawDimRect(startX - 40.0f, startY - 10.0f, startX + 300.0f, startY + 8.0f, Colors.getColor(44, 44, 45));
                RenderUtil.drawDimRect(startX - 40.0f, startY + 8.0f, startX + 300.0f, startY + 260.0f, Colors.getColor(37, 37, 38));
                RenderUtil.circle(startX + 292.0f, startY - 4.0f, 4.0f, new Color(-14848033).brighter());
                if (this.isSettingsButtonHovered(startX + 288.0f, startY - 6.0f, startX + 344.0f, startY + 2.0f, mouseX, mouseY) && Mouse.isButtonDown((int)0)) {
                    this.MIND = false;
                }
                GameFontRenderer gamefontrenderer = Fonts.fontSFUI35;
                Fonts.fontSFUI35.drawString(currentModule.getName(), startX - 35.0f, startY - 8.0f, -1);
                GL11.glPushMatrix();
                if (this.animationX == 390.0f) {
                    RenderUtil.doGlScissor((int)startX - 40, (int)startY + 8, (int)startX + 300, RenderUtil.height());
                }
                for (BoolValue value1 : this.modBooleanValue) {
                    if (f - (float)this.valueStart > startY + 220.0f) break;
                    Gui.func_73734_a((int)1, (int)1, (int)1, (int)1, (int)-1);
                    x = startX + 250.0f;
                    gamefontrenderer.drawString(value1.getName(), startX - 30.0f, f - (float)this.valueStart, new Color(255, 255, 255).getRGB());
                    this.buttonColor = (Boolean)value1.getValue() != false ? new Color(-14848033).brighter() : new Color(80, 80, 80);
                    RenderUtil.circle(x + 35.0f, f - (float)this.valueStart + 2.0f, 4.0f, this.buttonColor.getRGB());
                    if (this.isCheckBoxHovered(x + 30.0f, f - (float)this.valueStart, x + 38.0f, f - (float)this.valueStart + 9.0f, mouseX, mouseY)) {
                        if (!this.previousmouse && Mouse.isButtonDown((int)0)) {
                            this.previousmouse = true;
                            this.mouse = true;
                        }
                        if (this.mouse) {
                            value1.setValue((Boolean)value1.getValue() == false);
                            this.mouse = false;
                        }
                    }
                    if (!Mouse.isButtonDown((int)0)) {
                        this.previousmouse = false;
                    }
                    f += 20.0f;
                }
                for (FloatValue floatvalue : this.modDoubleValue) {
                    if (f - (float)this.valueStart > startY + 220.0f) break;
                    if (doubleValueMap.containsKey(floatvalue)) {
                        uislider = (UISlider)doubleValueMap.get(floatvalue);
                    } else {
                        uislider = new UISlider(floatvalue);
                        doubleValueMap.put(floatvalue, uislider);
                    }
                    uislider.drawAll(startX + 45.0f, f - (float)this.valueStart, mouseX, mouseY);
                    f += 22.0f;
                }
                for (IntegerValue integervalue : this.modIntValue) {
                    if (f - (float)this.valueStart > startY + 220.0f) break;
                    if (IntValueMap.containsKey(integervalue)) {
                        uislider = (UISlider)IntValueMap.get(integervalue);
                    } else {
                        uislider = new UISlider(integervalue);
                        IntValueMap.put(integervalue, uislider);
                    }
                    uislider.drawAlll(startX + 45.0f, f - (float)this.valueStart, mouseX, mouseY);
                    f += 22.0f;
                }
                for (ListValue listvalue : this.modModeValue) {
                    if (f - (float)this.valueStart > startY + 220.0f) break;
                    x = startX + 250.0f;
                    RenderUtil.drawRect(x - 40.0f, f - (float)this.valueStart - 1.0f, x + 40.0f, f - (float)this.valueStart + 12.0f, new Color(60, 60, 60).getRGB());
                    Fonts.fontSFUI35.drawString(listvalue.getName(), startX - 30.0f, f - (float)this.valueStart, new Color(255, 255, 255).getRGB());
                    Fonts.fontSFUI35.drawCenteredString((String)listvalue.getValue(), x - 2.0f, f - (float)this.valueStart + 2.0f, -1);
                    if (this.isStringHovered(x - 40.0f, f - (float)this.valueStart - 1.0f, x + 40.0f, f - (float)this.valueStart + 12.0f, mouseX, mouseY)) {
                        if (Mouse.isButtonDown((int)0) && !this.previousmouse) {
                            String current = (String)listvalue.getValue();
                            listvalue.set(listvalue.getValues()[listvalue.getModeListNumber(current) + 1 >= listvalue.getValues().length ? 0 : listvalue.getModeListNumber(current) + 1]);
                            this.previousmouse = true;
                        }
                        if (!Mouse.isButtonDown((int)0)) {
                            this.previousmouse = false;
                        }
                    }
                    f += 20.0f;
                }
                GL11.glPopMatrix();
                GL11.glDisable((int)3089);
                GL11.glPopMatrix();
            } else {
                this.animationX = (float)RenderUtil.getAnimationState(this.animationX, 0.0, 800.0);
                this.animationY = (float)RenderUtil.getAnimationState(this.animationY, 0.0, 800.0);
            }
        }
    }

    public boolean isStringHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= f && (float)mouseX <= g && (float)mouseY >= y && (float)mouseY <= y2;
    }

    public boolean isSettingsButtonHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= x && (float)mouseX <= x2 && (float)mouseY >= y && (float)mouseY <= y2;
    }

    public boolean isButtonHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= f && (float)mouseX <= g && (float)mouseY >= y && (float)mouseY <= y2;
    }

    public boolean isCheckBoxHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= f && (float)mouseX <= g && (float)mouseY >= y && (float)mouseY <= y2;
    }

    public boolean isCategoryHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= x && (float)mouseX <= x2 && (float)mouseY >= y && (float)mouseY <= y2;
    }

    public boolean isHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= x && (float)mouseX <= x2 && (float)mouseY >= y && (float)mouseY <= y2;
    }

    public void func_146281_b() {
        this.opacity.setOpacity(0.0f);
    }
}

