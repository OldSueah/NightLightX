/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Mouse
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.render;

import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.Animation;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.Direction;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.impl.SmoothStepAnimation;
import org.lwjgl.input.Mouse;

public class Scroll {
    public float maxScroll = Float.MAX_VALUE;
    public float minScroll = 0.0f;
    public float rawScroll;
    public float scroll;
    private Animation scrollAnimation = new SmoothStepAnimation(0, 0.0, Direction.BACKWARDS);

    public void onScroll(int ms) {
        this.scroll = (float)((double)this.rawScroll - this.scrollAnimation.getOutput());
        this.rawScroll += (float)Mouse.getDWheel() / 4.0f;
        this.rawScroll = Math.max(Math.min(this.minScroll, this.rawScroll), -this.maxScroll);
        this.scrollAnimation = new SmoothStepAnimation(ms, this.rawScroll - this.scroll, Direction.BACKWARDS);
    }

    public boolean isScrollAnimationDone() {
        return this.scrollAnimation.isDone();
    }

    public double getScroll() {
        this.scroll = (float)((double)this.rawScroll - this.scrollAnimation.getOutput());
        return this.scroll;
    }

    public void setMinScroll(float val) {
        this.minScroll = val;
    }

    public void setMaxScroll(float val) {
        this.maxScroll = val;
    }
}

