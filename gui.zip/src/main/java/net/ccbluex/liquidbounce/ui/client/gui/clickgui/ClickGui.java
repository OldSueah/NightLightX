/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.RenderHelper
 *  org.lwjgl.input.Mouse
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.ccbluex.liquidbounce.FDPClient;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.ui.client.gui.ClickGUIModule;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.Panel;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.elements.ButtonElement;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.elements.Element;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.elements.ModuleElement;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.Style;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.SlowlyStyle;
import net.ccbluex.liquidbounce.ui.client.gui.options.modernuiLaunchOption;
import net.ccbluex.liquidbounce.ui.client.hud.designer.GuiHudDesigner;
import net.ccbluex.liquidbounce.ui.font.AWTFontRenderer;
import net.ccbluex.liquidbounce.utils.render.ColorUtils;
import net.ccbluex.liquidbounce.utils.render.EaseUtils;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import org.lwjgl.input.Mouse;

public class ClickGui
extends GuiScreen {
    public final List<Panel> panels = new ArrayList<Panel>();
    public Style style = new SlowlyStyle();
    private Panel clickedPanel;
    private int mouseX;
    private int mouseY;
    private double slide;
    private double progress = 0.0;

    public ClickGui() {
        int width = 100;
        int height = 18;
        int yPos = 5;
        for (final ModuleCategory category : ModuleCategory.values()) {
            this.panels.add(new Panel(category.getDisplayName(), category, 100, yPos, 100, 18, false){

                @Override
                public void setupItems() {
                    for (Module module : FDPClient.moduleManager.getModules()) {
                        if (module.getCategory() != category) continue;
                        this.getElements().add(new ModuleElement(module));
                    }
                }
            });
            yPos += 20;
        }
    }

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        float trueCguiScale;
        FDPClient.moduleManager.getModule(ClickGUIModule.class);
        if (((String)ClickGUIModule.INSTANCE.getStyleValue().get()).equals("Jello")) {
            trueCguiScale = 1.0f;
        } else {
            FDPClient.moduleManager.getModule(ClickGUIModule.class);
            if (((String)ClickGUIModule.INSTANCE.getStyleValue().get()).equals("Glow")) {
                trueCguiScale = 1.0f;
            } else {
                FDPClient.moduleManager.getModule(ClickGUIModule.class);
                trueCguiScale = ((Float)ClickGUIModule.INSTANCE.getScaleValue().get()).floatValue();
            }
        }
        double scale = trueCguiScale;
        this.progress = this.progress < 1.0 ? (this.progress += 0.1 * (double)(1.0f - partialTicks)) : 1.0;
        Objects.requireNonNull(FDPClient.moduleManager.getModule(ClickGUIModule.class));
        switch (((String)ClickGUIModule.INSTANCE.getAnimationValue().get()).toLowerCase()) {
            case "liquidbounce": 
            case "ziul": {
                this.slide = EaseUtils.easeOutBack(this.progress);
                break;
            }
            case "slide": 
            case "zoom": 
            case "bread": {
                this.slide = EaseUtils.easeOutQuart(this.progress);
                break;
            }
            case "none": {
                this.slide = 1.0;
            }
        }
        if (Mouse.isButtonDown((int)0) && mouseX >= 5 && mouseX <= 50 && mouseY <= this.field_146295_m - 5 && mouseY >= this.field_146295_m - 50) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiHudDesigner());
        }
        AWTFontRenderer.Companion.setAssumeNonVolatile(true);
        mouseX = (int)((double)mouseX / scale);
        mouseY = (int)((double)mouseY / scale);
        this.mouseX = mouseX;
        this.mouseY = mouseY;
        Objects.requireNonNull(FDPClient.moduleManager.getModule(ClickGUIModule.class));
        switch ((String)ClickGUIModule.INSTANCE.getBackgroundValue().get()) {
            case "Default": {
                this.func_146276_q_();
                break;
            }
            case "Gradient": {
                this.func_73733_a(0, 0, this.field_146294_l, this.field_146295_m, ColorUtils.reAlpha(ClickGUIModule.INSTANCE.generateColor(), 40).getRGB(), ClickGUIModule.INSTANCE.generateColor().getRGB());
                break;
            }
        }
        this.func_146276_q_();
        int defaultHeight1 = this.field_146295_m;
        int defaultWidth1 = this.field_146294_l;
        Objects.requireNonNull(FDPClient.moduleManager.getModule(ClickGUIModule.class));
        switch (((String)ClickGUIModule.INSTANCE.getAnimationValue().get()).toLowerCase()) {
            case "bread": {
                GlStateManager.func_179137_b((double)0.0, (double)((1.0 - this.slide) * (double)this.field_146295_m * 2.0), (double)0.0);
                GlStateManager.func_179139_a((double)scale, (double)(scale + (1.0 - this.slide) * 2.0), (double)scale);
                break;
            }
            case "slide": 
            case "liquidbounce": {
                GlStateManager.func_179137_b((double)0.0, (double)((1.0 - this.slide) * (double)this.field_146295_m * 2.0), (double)0.0);
                GlStateManager.func_179139_a((double)scale, (double)scale, (double)scale);
                break;
            }
            case "zoom": {
                GlStateManager.func_179137_b((double)((1.0 - this.slide) * ((double)this.field_146294_l / 2.0)), (double)((1.0 - this.slide) * ((double)this.field_146295_m / 2.0)), (double)((1.0 - this.slide) * ((double)this.field_146294_l / 2.0)));
                GlStateManager.func_179139_a((double)(scale * this.slide), (double)(scale * this.slide), (double)(scale * this.slide));
                break;
            }
            case "ziul": {
                GlStateManager.func_179137_b((double)((1.0 - this.slide) * ((double)this.field_146294_l / 2.0)), (double)((1.0 - this.slide) * ((double)this.field_146295_m / 2.0)), (double)0.0);
                GlStateManager.func_179139_a((double)(scale * this.slide), (double)(scale * this.slide), (double)(scale * this.slide));
                break;
            }
            case "none": {
                GlStateManager.func_179139_a((double)scale, (double)scale, (double)scale);
            }
        }
        for (Panel panel : this.panels) {
            panel.updateFade(RenderUtils.deltaTime);
            panel.drawScreen(mouseX, mouseY, partialTicks);
        }
        for (Panel panel : this.panels) {
            for (Element element : panel.getElements()) {
                if (!(element instanceof ModuleElement)) continue;
                ModuleElement moduleElement = (ModuleElement)element;
                if (mouseX == 0 || mouseY == 0 || !moduleElement.isHovering(mouseX, mouseY) || !moduleElement.isVisible() || element.getY() > panel.getY() + panel.getFade()) continue;
                this.style.drawDescription(mouseX, mouseY, moduleElement.getModule().getDescription());
            }
        }
        if (Mouse.hasWheel()) {
            int wheel = Mouse.getDWheel();
            boolean handledScroll = false;
            for (int i = this.panels.size() - 1; i >= 0; --i) {
                if (!this.panels.get(i).handleScroll(mouseX, mouseY, wheel)) continue;
                handledScroll = true;
                break;
            }
            if (!handledScroll) {
                this.handleScroll(wheel);
            }
        }
        GlStateManager.func_179140_f();
        RenderHelper.func_74518_a();
        switch (((String)Objects.requireNonNull(FDPClient.moduleManager.getModule(ClickGUIModule.class)).getAnimationValue().get()).toLowerCase()) {
            case "bread": 
            case "slide": 
            case "liquidbounce": {
                GlStateManager.func_179137_b((double)0.0, (double)((1.0 - this.slide) * (double)this.field_146295_m * -2.0), (double)0.0);
                break;
            }
            case "zoom": {
                GlStateManager.func_179137_b((double)(-1.0 * (1.0 - this.slide) * ((double)this.field_146294_l / 2.0)), (double)(-1.0 * (1.0 - this.slide) * ((double)this.field_146295_m / 2.0)), (double)(-1.0 * (1.0 - this.slide) * ((double)this.field_146294_l / 2.0)));
                break;
            }
            case "ziul": {
                GlStateManager.func_179137_b((double)(-1.0 * (1.0 - this.slide) * ((double)this.field_146294_l / 2.0)), (double)(-1.0 * (1.0 - this.slide) * ((double)this.field_146295_m / 2.0)), (double)0.0);
            }
        }
        GlStateManager.func_179152_a((float)1.0f, (float)1.0f, (float)1.0f);
        AWTFontRenderer.Companion.setAssumeNonVolatile(false);
        super.func_73863_a(mouseX, mouseY, partialTicks);
    }

    private void handleScroll(int wheel) {
        if (wheel == 0) {
            return;
        }
        for (Panel panel : this.panels) {
            panel.setY(panel.getY() + wheel);
        }
    }

    protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
        float trueCguiScale = ((String)FDPClient.moduleManager.getModule(ClickGUIModule.class).getStyleValue().get()).equals("Jello") ? 1.0f : (((String)FDPClient.moduleManager.getModule(ClickGUIModule.class).getStyleValue().get()).equals("Glow") ? 1.0f : ((Float)FDPClient.moduleManager.getModule(ClickGUIModule.class).getScaleValue().get()).floatValue());
        double scale = trueCguiScale;
        mouseX = (int)((double)mouseX / scale);
        mouseY = (int)((double)mouseY / scale);
        for (Panel panel : this.panels) {
            panel.mouseClicked(mouseX, mouseY, mouseButton);
            panel.drag = false;
            if (mouseButton != 0 || !panel.isHovering(mouseX, mouseY)) continue;
            this.clickedPanel = panel;
        }
        if (this.clickedPanel != null) {
            this.clickedPanel.x2 = this.clickedPanel.x - mouseX;
            this.clickedPanel.y2 = this.clickedPanel.y - mouseY;
            this.clickedPanel.drag = true;
            this.panels.remove(this.clickedPanel);
            this.panels.add(this.clickedPanel);
            this.clickedPanel = null;
        }
        super.func_73864_a(mouseX, mouseY, mouseButton);
    }

    protected void func_146286_b(int mouseX, int mouseY, int state) {
        float trueCguiScale = ((String)FDPClient.moduleManager.getModule(ClickGUIModule.class).getStyleValue().get()).equals("Jello") ? 1.0f : (((String)FDPClient.moduleManager.getModule(ClickGUIModule.class).getStyleValue().get()).equals("Glow") ? 1.0f : ((Float)FDPClient.moduleManager.getModule(ClickGUIModule.class).getScaleValue().get()).floatValue());
        double scale = trueCguiScale;
        mouseX = (int)((double)mouseX / scale);
        mouseY = (int)((double)mouseY / scale);
        for (Panel panel : this.panels) {
            panel.mouseReleased(mouseX, mouseY, state);
        }
        super.func_146286_b(mouseX, mouseY, state);
    }

    public void func_73876_c() {
        for (Panel panel : this.panels) {
            for (Element element : panel.getElements()) {
                if (element instanceof ButtonElement) {
                    ButtonElement buttonElement = (ButtonElement)element;
                    if (buttonElement.isHovering(this.mouseX, this.mouseY)) {
                        if (buttonElement.hoverTime < 7) {
                            ++buttonElement.hoverTime;
                        }
                    } else if (buttonElement.hoverTime > 0) {
                        --buttonElement.hoverTime;
                    }
                }
                if (!(element instanceof ModuleElement)) continue;
                if (((ModuleElement)element).getModule().getState()) {
                    if (((ModuleElement)element).slowlyFade < 255) {
                        ((ModuleElement)element).slowlyFade += 20;
                    }
                } else if (((ModuleElement)element).slowlyFade > 0) {
                    ((ModuleElement)element).slowlyFade -= 20;
                }
                if (((ModuleElement)element).slowlyFade > 255) {
                    ((ModuleElement)element).slowlyFade = 255;
                }
                if (((ModuleElement)element).slowlyFade >= 0) continue;
                ((ModuleElement)element).slowlyFade = 0;
            }
        }
        super.func_73876_c();
    }

    public void func_146281_b() {
        FDPClient.fileManager.saveConfig(modernuiLaunchOption.getClickGuiConfig());
        this.slide = 0.0;
        this.progress = 0.0;
    }

    public boolean func_73868_f() {
        return false;
    }
}

