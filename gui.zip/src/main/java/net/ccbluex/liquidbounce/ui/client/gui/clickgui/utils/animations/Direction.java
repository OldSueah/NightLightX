/*
 * Decompiled with CFR 0.152.
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations;

public enum Direction {
    FORWARDS,
    BACKWARDS;

}

