/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.opengl.GL11
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.tenacity.impl;

import java.awt.Color;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.ui.client.gui.ClickGUIModule;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.fonts.impl.Fonts;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.fonts.logo.info;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.tenacity.impl.Component;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.tenacity.impl.SettingComponents;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.Animation;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.Direction;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.impl.DecelerateAnimation;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.impl.EaseInOutQuad;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.normal.Main;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.render.DrRenderUtils;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

public class ModuleRect
extends Component {
    public final info client = info.getInstance();
    public final Module module;
    private final SettingComponents settingComponents;
    private final Animation animation = new EaseInOutQuad(300, 1.0, Direction.BACKWARDS);
    private final Animation arrowAnimation = new EaseInOutQuad(250, 1.0, Direction.BACKWARDS);
    private final Animation hoverAnimation = new DecelerateAnimation(250, 1.0, Direction.BACKWARDS);
    public Animation settingAnimation;
    public Animation openingAnimation;
    public float x;
    public float y;
    public float width;
    public float height;
    public float panelLimitY;
    public int alphaAnimation;
    int clickX;
    int clickY;
    private double settingSize;

    public ModuleRect(Module module) {
        this.module = module;
        this.settingComponents = new SettingComponents(module);
    }

    @Override
    public void initGui() {
        this.animation.setDirection(this.module.getState() ? Direction.FORWARDS : Direction.BACKWARDS);
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (this.module.getExpanded()) {
            this.settingComponents.keyTyped(typedChar, keyCode);
        }
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        Color rectColor = new Color(43, 45, 50, this.alphaAnimation);
        Color textColor = new Color(255, 255, 255, this.alphaAnimation);
        Color debcolor = new Color(ClickGUIModule.INSTANCE.generateColor().getRGB());
        Color clickModColor = DrRenderUtils.applyOpacity(debcolor, (float)this.alphaAnimation / 255.0f);
        float alpha = (float)this.alphaAnimation / 255.0f;
        boolean hoveringModule = DrRenderUtils.isHovering(this.x, this.y, this.width, this.height, mouseX, mouseY);
        this.hoverAnimation.setDirection(hoveringModule ? Direction.FORWARDS : Direction.BACKWARDS);
        DrRenderUtils.drawRect2(this.x, this.y, this.width, this.height, DrRenderUtils.interpolateColor(rectColor.getRGB(), DrRenderUtils.brighter(rectColor, 0.8f).getRGB(), (float)this.hoverAnimation.getOutput()));
        DrRenderUtils.drawRect2(this.x, this.y, this.width, this.height, DrRenderUtils.applyOpacity(clickModColor, (float)this.animation.getOutput()).getRGB());
        Fonts.SF.SF_20.SF_20.drawString((CharSequence)this.module.getName(), this.x + 5.0f, this.y + Fonts.SF.SF_20.SF_20.getMiddleOfBox(this.height), textColor.getRGB());
        if (Keyboard.isKeyDown((int)15) && this.module.getKeyBind() != 0) {
            String keyName = Keyboard.getKeyName((int)this.module.getKeyBind());
            Fonts.SF.SF_20.SF_20.drawString((CharSequence)keyName, this.x + this.width - (float)Fonts.SF.SF_20.SF_20.stringWidth(keyName) - 5.0f, this.y + Fonts.SF.SF_20.SF_20.getMiddleOfBox(this.height), textColor.getRGB());
        } else {
            float arrowSize = 6.0f;
            this.arrowAnimation.setDirection(this.module.getExpanded() ? Direction.FORWARDS : Direction.BACKWARDS);
            DrRenderUtils.setAlphaLimit(0.0f);
            DrRenderUtils.resetColor();
            DrRenderUtils.drawClickGuiArrow(this.x + this.width - (arrowSize + 5.0f), this.y + this.height / 2.0f - 2.0f, arrowSize, this.arrowAnimation, textColor.getRGB());
        }
        Color settingRectColor = new Color(32, 32, 32, this.alphaAnimation);
        double settingHeight = this.settingComponents.settingSize * this.settingAnimation.getOutput();
        if (this.module.getExpanded() || !this.settingAnimation.isDone()) {
            DrRenderUtils.drawRect2(this.x, this.y + this.height, this.width, settingHeight * (double)this.height, settingRectColor.getRGB());
            boolean hoveringSettingsOrModule = DrRenderUtils.isHovering(this.x, this.y, this.width, (float)((double)this.height + settingHeight * (double)this.height), mouseX, mouseY);
            if (((Boolean)ClickGUIModule.INSTANCE.getBackback().get()).booleanValue()) {
                DrRenderUtils.resetColor();
                float accentAlpha = (float)(0.85 * this.animation.getOutput()) * alpha;
                DrRenderUtils.drawRect2(this.x, this.y + this.height, this.width, (float)(settingHeight * (double)this.height), DrRenderUtils.applyOpacity(clickModColor, accentAlpha).getRGB());
            }
            this.settingComponents.x = this.x;
            this.settingComponents.y = this.y + this.height;
            this.settingComponents.width = this.width;
            this.settingComponents.rectHeight = this.height;
            this.settingComponents.panelLimitY = this.panelLimitY;
            this.settingComponents.alphaAnimation = this.alphaAnimation;
            this.settingComponents.settingHeightScissor = this.settingAnimation;
            if (!this.settingAnimation.isDone()) {
                GL11.glEnable((int)3089);
                DrRenderUtils.scissor(this.x, this.y + this.height, this.width, settingHeight * (double)this.height);
                this.settingComponents.drawScreen(mouseX, mouseY);
                DrRenderUtils.drawGradientRect2(this.x, this.y + this.height, this.width, 6.0, new Color(0, 0, 0, 60).getRGB(), new Color(0, 0, 0, 0).getRGB());
                DrRenderUtils.drawGradientRect2(this.x, (double)(this.y + 11.0f) + settingHeight * (double)this.height, this.width, 6.0, new Color(0, 0, 0, 0).getRGB(), new Color(0, 0, 0, 60).getRGB());
                GL11.glDisable((int)3089);
            } else {
                this.settingComponents.drawScreen(mouseX, mouseY);
                DrRenderUtils.drawGradientRect2(this.x, this.y + this.height, this.width, 6.0, new Color(0, 0, 0, 60).getRGB(), new Color(0, 0, 0, 0).getRGB());
                DrRenderUtils.drawGradientRect2(this.x, (double)(this.y + 11.0f) + settingHeight * (double)this.height, this.width, 6.0, new Color(0, 0, 0, 0).getRGB(), new Color(0, 0, 0, 60).getRGB());
            }
        }
        this.settingSize = settingHeight;
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        boolean hoveringModule;
        boolean bl = hoveringModule = this.isClickable(this.y, this.panelLimitY) && DrRenderUtils.isHovering(this.x, this.y, this.width, this.height, mouseX, mouseY);
        if (hoveringModule) {
            switch (button) {
                case 0: {
                    this.clickX = mouseX;
                    this.clickY = mouseY;
                    this.animation.setDirection(!this.module.getState() ? Direction.FORWARDS : Direction.BACKWARDS);
                    this.module.toggle();
                    break;
                }
                case 1: {
                    this.module.setExpanded(!this.module.getExpanded());
                }
            }
        }
        if (this.module.getExpanded()) {
            this.settingComponents.mouseClicked(mouseX, mouseY, button);
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        if (this.module.getExpanded()) {
            this.settingComponents.mouseReleased(mouseX, mouseY, state);
        }
    }

    public double getSettingSize() {
        return this.settingSize;
    }

    public boolean isClickable(float y, float panelLimitY) {
        return y > panelLimitY && y < panelLimitY + Main.allowedClickGuiHeight + 17.0f;
    }
}

