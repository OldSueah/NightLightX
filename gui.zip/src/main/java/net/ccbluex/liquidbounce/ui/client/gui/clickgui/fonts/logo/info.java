/*
 * Decompiled with CFR 0.152.
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui.fonts.logo;

import net.ccbluex.liquidbounce.ui.client.gui.clickgui.fonts.api.FontManager;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.fonts.impl.SimpleFontManager;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.tenacity.SideGui.SideGui;

public class info {
    public static String Name = "FDPCLIENT";
    public static String version = "";
    public static String username;
    private final SideGui sideGui = new SideGui();
    private static info INSTANCE;
    public static final FontManager fontManager;

    public SideGui getSideGui() {
        return this.sideGui;
    }

    public static info getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new info();
        }
        return INSTANCE;
    }

    public static FontManager getFontManager() {
        return fontManager;
    }

    static {
        fontManager = SimpleFontManager.create();
    }
}

