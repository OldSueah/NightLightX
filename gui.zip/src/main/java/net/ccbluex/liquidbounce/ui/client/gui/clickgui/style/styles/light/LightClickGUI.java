/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.FontRenderer
 *  net.minecraft.client.gui.GuiScreen
 *  net.minecraft.client.gui.GuiYesNoCallback
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.util.ResourceLocation
 *  org.lwjgl.input.Keyboard
 *  org.lwjgl.input.Mouse
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.light;

import java.awt.Color;
import java.io.IOException;
import net.ccbluex.liquidbounce.FDPClient;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.ModuleCategory;
import net.ccbluex.liquidbounce.features.value.BoolValue;
import net.ccbluex.liquidbounce.features.value.FloatValue;
import net.ccbluex.liquidbounce.features.value.IntegerValue;
import net.ccbluex.liquidbounce.features.value.ListValue;
import net.ccbluex.liquidbounce.features.value.TextValue;
import net.ccbluex.liquidbounce.features.value.Value;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.light.GuiExit;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.light.LightSettings.InputBox;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.light.ModuleSettings.Settings;
import net.ccbluex.liquidbounce.ui.client.hud.designer.GuiHudDesigner;
import net.ccbluex.liquidbounce.ui.font.Fonts;
import net.ccbluex.liquidbounce.utils.AnimationHelper;
import net.ccbluex.liquidbounce.utils.render.RenderUtils;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiYesNoCallback;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class LightClickGUI
extends GuiScreen
implements GuiYesNoCallback {
    private ModuleCategory currentCategory = ModuleCategory.COMBAT;
    private Module currentModule = FDPClient.moduleManager.getModuleInCategory(this.currentCategory).get(0);
    private float startX = 50.0f;
    private float startY = 25.0f;
    private int moduleStart = 0;
    private int valueStart = 0;
    private boolean previousMouse = true;
    private boolean mouse;
    private float moveX = 0.0f;
    private float moveY = 0.0f;
    private float oldX = 0.0f;
    private float oldY = 0.0f;
    private final FontRenderer defaultFont = Fonts.font35;
    private final FontRenderer logoFont = Fonts.font40;
    private final int fontHeight;
    private boolean rightClickMouse;
    private boolean categoryMouse;
    private int animationHeight;
    private int categoryAnimation;
    private int moduleAnimation;
    private boolean moduleHover;
    private float guiScale;
    private final AnimationHelper alphaAnim;
    private final AnimationHelper valueAnim;
    private int categoryYpos;
    private InputBox searchBox;
    private boolean firstSetAnimation;

    public LightClickGUI() {
        this.fontHeight = Math.round(this.defaultFont.field_78288_b / 2);
        this.rightClickMouse = false;
        this.categoryMouse = false;
        this.animationHeight = 0;
        this.categoryAnimation = 0;
        this.moduleAnimation = 0;
        this.moduleHover = false;
        this.guiScale = 0.0f;
        this.alphaAnim = new AnimationHelper();
        this.valueAnim = new AnimationHelper();
        this.categoryYpos = 35;
        this.firstSetAnimation = false;
        this.alphaAnim.resetAlpha();
        this.valueAnim.resetAlpha();
    }

    public void func_73866_w_() {
        this.firstSetAnimation = false;
        this.alphaAnim.resetAlpha();
        this.valueAnim.resetAlpha();
        this.searchBox = new InputBox(1, (int)this.startX, (int)this.startY + 20, 45, 8);
    }

    protected void func_73864_a(int p_mouseClicked_1_, int p_mouseClicked_2_, int p_mouseClicked_3_) throws IOException {
        super.func_73864_a(p_mouseClicked_1_, p_mouseClicked_2_, p_mouseClicked_3_);
        this.searchBox.mouseClicked(p_mouseClicked_1_, p_mouseClicked_2_, p_mouseClicked_3_);
    }

    public void func_73876_c() {
        this.searchBox.updateCursorCounter();
    }

    public void func_73869_a(char typedChar, int keyCode) {
        if (keyCode == 1) {
            this.field_146297_k.func_147108_a(null);
        }
        if (typedChar == '\t' && this.searchBox.isFocused()) {
            this.searchBox.setFocused(!this.searchBox.isFocused());
        }
        this.searchBox.textboxKeyTyped(typedChar, keyCode);
    }

    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        int colorV;
        int moduleColor;
        Module module;
        RenderUtils.drawImage(new ResourceLocation("fdpclient/ui/clickgui/hud.png"), 9, this.field_146295_m - 41, 32, 32);
        if (!this.firstSetAnimation) {
            for (Module i : FDPClient.moduleManager.getModules()) {
                i.getAnimation().animationX = i.getState() ? 5.0f : -5.0f;
                for (Value<?> j : i.getValues()) {
                    if (!(j instanceof BoolValue)) continue;
                    BoolValue boolValue = (BoolValue)j;
                    boolValue.getAnimation().animationX = (Boolean)boolValue.get() != false ? 5.0f : -5.0f;
                }
            }
            this.firstSetAnimation = true;
        }
        this.searchBox.xPosition = (int)this.startX;
        this.searchBox.yPosition = (int)(this.startY + 15.0f);
        this.searchBox.setMaxStringLength(20);
        if (this.alphaAnim.getAlpha() == 250) {
            this.alphaAnim.alpha = 255;
        } else {
            this.alphaAnim.updateAlpha(25);
        }
        if (this.valueAnim.getAlpha() == 240) {
            this.alphaAnim.alpha = 255;
        } else {
            this.valueAnim.updateAlpha(30);
        }
        if (this.guiScale < 100.0f) {
            this.guiScale += 10.0f;
        }
        GlStateManager.func_179152_a((float)(this.guiScale / 100.0f), (float)(this.guiScale / 100.0f), (float)(this.guiScale / 100.0f));
        Settings settings2 = new Settings(this.valueAnim);
        if (Mouse.isButtonDown((int)0) && mouseX >= 5 && mouseX <= 50 && mouseY <= this.field_146295_m - 5 && mouseY >= this.field_146295_m - 50) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiHudDesigner());
        }
        if ((this.isHovered(this.startX - 5.0f, this.startY, this.startX + 400.0f, this.startY + 25.0f, mouseX, mouseY) || this.isHovered(this.startX - 5.0f, this.startY, this.startX + 400.0f, this.startY + 25.0f, (int)this.oldX, (int)this.oldY)) && Mouse.isButtonDown((int)0)) {
            if (this.moveX == 0.0f && this.moveY == 0.0f) {
                this.moveX = (float)mouseX - this.startX;
                this.moveY = (float)mouseY - this.startY;
            } else {
                this.startX = (float)mouseX - this.moveX;
                this.startY = (float)mouseY - this.moveY;
            }
            this.previousMouse = true;
        } else if (this.moveX != 0.0f || this.moveY != 0.0f) {
            this.moveX = 0.0f;
            this.moveY = 0.0f;
        }
        this.oldX = mouseX;
        this.oldY = mouseY;
        Fonts.font35.drawString("Made by The Smart Cat, Dummix", this.startX + 210.0f, this.startY + 295.0f, new Color(200, 200, 200).getRGB());
        RenderUtils.drawRoundedRect2((int)this.startX - 5, (int)this.startY + 10, (int)this.startX + 400, (int)this.startY + 310, 3.0f, new Color(230, 230, 230, 255).getRGB());
        RenderUtils.drawRoundedRect2((int)this.startX - 5, (int)this.startY, (int)this.startX + 400, (int)this.startY + 25, 10.0f, new Color(250, 250, 250, 255).getRGB());
        this.defaultFont.func_78276_b(this.searchBox.getText().isEmpty() && !this.searchBox.isFocused() ? "Search..." : this.searchBox.getText(), (int)(this.startX + 3.0f), (int)(this.startY + 15.0f), new Color(80, 80, 80).getRGB());
        if (this.currentModule == null) {
            this.logoFont.func_175063_a("No Modules Selected", this.startX + 80.0f, this.startY + 130.0f, new Color(100, 100, 100).getRGB());
        }
        int m = Mouse.getDWheel();
        if (this.searchBox.getText().isEmpty() && this.isCategoryHovered(this.startX + 60.0f, this.startY + 40.0f, this.startX + 200.0f, this.startY + 280.0f, mouseX, mouseY)) {
            if (m < 0 && this.moduleStart < FDPClient.moduleManager.getModuleInCategory(this.currentCategory).size() - 8) {
                ++this.moduleStart;
            }
            if (m > 0 && this.moduleStart > 0) {
                --this.moduleStart;
            }
        }
        if (this.isCategoryHovered(this.startX + 200.0f, this.startY, this.startX + 400.0f, this.startY + 280.0f, mouseX, mouseY)) {
            if (m < 0 && this.valueStart < this.currentModule.getValues().size() - 11) {
                ++this.valueStart;
            }
            if (m > 0 && this.valueStart > 0) {
                --this.valueStart;
            }
        }
        this.logoFont.func_78276_b(this.currentCategory.getDisplayName(), (int)(this.startX + 60.0f), (int)(this.startY + 10.0f), new Color(100, 100, 100, this.alphaAnim.getAlpha()).getRGB());
        RenderUtils.circle(this.startX + 390.0f, this.startY + 8.0f, 1.5f, new Color(31, 158, 255).getRGB());
        if (this.isCheckBoxHovered(this.startX + 388.0f, this.startY + 6.0f, this.startX + 391.0f, this.startY + 9.0f, mouseX, mouseY) && Mouse.isButtonDown((int)0)) {
            this.field_146297_k.func_147108_a((GuiScreen)new GuiExit());
        }
        this.moduleHover = false;
        if (!this.searchBox.getText().isEmpty()) {
            if (this.isCategoryHovered(this.startX + 60.0f, this.startY + 40.0f, this.startX + 200.0f, this.startY + 280.0f, mouseX, mouseY)) {
                if (m < 0 && this.moduleStart < FDPClient.moduleManager.getModuleInCategory(this.currentCategory).size() - 8) {
                    ++this.moduleStart;
                }
                if (m > 0 && this.moduleStart > 0) {
                    --this.moduleStart;
                }
            }
            if (this.isCategoryHovered(this.startX + 200.0f, this.startY + 40.0f, this.startX + 400.0f, this.startY + 280.0f, mouseX, mouseY)) {
                if (m < 0 && this.valueStart < this.currentModule.getValues().size() - 11) {
                    ++this.valueStart;
                }
                if (m > 0 && this.valueStart > 0) {
                    --this.valueStart;
                }
            }
            float mY = this.startY + 30.0f;
            for (int i = 0; i < FDPClient.moduleManager.getModulesByName(this.searchBox.getText()).size(); ++i) {
                module = FDPClient.moduleManager.getModulesByName(this.searchBox.getText()).get(i);
                if (mY > this.startY + 280.0f) break;
                if (i < this.moduleStart) continue;
                moduleColor = new Color(118, 117, 117, this.alphaAnim.getAlpha()).getRGB();
                if (!Mouse.isButtonDown((int)0)) {
                    this.previousMouse = false;
                }
                colorV = 245 - (int)module.getAnimation().animationX;
                RenderUtils.drawRoundedRect2(this.startX + 63.0f, mY + 1.0f, this.startX + 187.0f, mY + 25.0f, 6.0f, new Color(210, 210, 210, this.alphaAnim.getAlpha()).getRGB());
                RenderUtils.drawRoundedRect2(this.startX + 64.0f, mY + 2.0f, this.startX + 186.0f, mY + 24.0f, 5.0f, new Color(230, 230, 230, this.alphaAnim.getAlpha()).getRGB());
                RenderUtils.drawRoundedRect2(this.startX + 65.0f, mY + 3.0f, this.startX + 185.0f, mY + 23.0f, 4.0f, new Color(colorV, colorV, colorV, this.alphaAnim.getAlpha()).getRGB());
                if (this.isSettingsButtonHovered(this.startX + 64.0f, mY + 2.0f, this.startX + 186.0f, mY + 24.0f, mouseX, mouseY) && this.categoryAnimation < 15) {
                    this.defaultFont.func_78276_b(module.getName(), (int)(this.startX + 70.0f) + Math.round(this.moduleAnimation / 2), (int)(mY + 6.0f + 5.0f - (float)this.fontHeight), moduleColor);
                    this.defaultFont.func_78276_b("KeyBind: " + (!Keyboard.getKeyName((int)module.getKeyBind()).equalsIgnoreCase("NONE") ? Keyboard.getKeyName((int)module.getKeyBind()) : "None"), (int)(this.startX + 70.0f) + Math.round(this.moduleAnimation / 2), (int)(mY + 13.0f + 5.0f - (float)this.fontHeight), new Color(80, 80, 80, this.alphaAnim.getAlpha()).getRGB() - 14 + this.moduleAnimation * 2);
                    ++this.moduleAnimation;
                    if (this.moduleAnimation > 6) {
                        this.moduleAnimation = 6;
                    }
                    this.moduleHover = true;
                    if (Mouse.isButtonDown((int)1) && !this.rightClickMouse && this.currentModule != module) {
                        this.currentModule = module;
                        this.valueAnim.resetAlpha();
                        this.valueStart = 0;
                        this.rightClickMouse = true;
                    }
                    if (!this.previousMouse && Mouse.isButtonDown((int)0)) {
                        module.setState(!module.getState());
                        this.previousMouse = true;
                    }
                    if (!this.previousMouse && Mouse.isButtonDown((int)1)) {
                        this.previousMouse = true;
                    }
                } else {
                    this.defaultFont.func_78276_b(module.getName(), (int)(this.startX + 70.0f), (int)(mY + 6.0f + 5.0f - (float)this.fontHeight), moduleColor);
                    this.defaultFont.func_78276_b("KeyBind: " + (!Keyboard.getKeyName((int)module.getKeyBind()).equalsIgnoreCase("NONE") ? Keyboard.getKeyName((int)module.getKeyBind()) : "None"), (int)(this.startX + 70.0f), (int)(mY + 13.0f + 5.0f - (float)this.fontHeight), new Color(80, 80, 80, this.alphaAnim.getAlpha()).getRGB());
                }
                if (this.rightClickMouse && !Mouse.isButtonDown((int)1)) {
                    this.rightClickMouse = false;
                }
                RenderUtils.drawRoundedRect2(this.startX + 160.0f, mY + 6.0f, this.startX + 180.0f, mY + 16.0f, 4.0f, module.getState() && module.getAnimation().getAnimationX() >= 3.0f ? new Color(29, 143, 237, this.alphaAnim.getAlpha()).getRGB() : new Color(114, 118, 125, this.alphaAnim.getAlpha()).getRGB());
                RenderUtils.circle(this.startX + 170.0f + module.getAnimation().getAnimationX(), mY + 11.0f, 4.0f, module.getState() ? new Color(255, 255, 255, this.alphaAnim.getAlpha()).getRGB() : new Color(164, 168, 175, this.alphaAnim.getAlpha()).getRGB());
                module.getAnimation().animationX = module.getState() ? (float)((double)module.getAnimation().animationX + (double)(5.0f - module.getAnimation().animationX) / 2.5) : (float)((double)module.getAnimation().animationX + (double)(-5.0f - module.getAnimation().animationX) / 2.5);
                mY += 28.0f;
            }
        }
        if (this.currentModule != null) {
            this.logoFont.func_78276_b(this.currentModule.getName(), (int)(this.startX + 205.0f), (int)(this.startY + 10.0f), new Color(100, 100, 100, this.valueAnim.getAlpha()).getRGB());
            float mY = this.startY + 30.0f;
            if (this.searchBox.getText().isEmpty()) {
                for (int i = 0; i < FDPClient.moduleManager.getModuleInCategory(this.currentCategory).size(); ++i) {
                    module = FDPClient.moduleManager.getModuleInCategory(this.currentCategory).get(i);
                    if (mY > this.startY + 280.0f) break;
                    if (i < this.moduleStart) continue;
                    moduleColor = new Color(118, 117, 117, this.alphaAnim.getAlpha()).getRGB();
                    if (!Mouse.isButtonDown((int)0)) {
                        this.previousMouse = false;
                    }
                    colorV = 245 - (int)module.getAnimation().animationX;
                    RenderUtils.drawRoundedRect2(this.startX + 63.0f, mY + 1.0f, this.startX + 187.0f, mY + 25.0f, 6.0f, new Color(210, 210, 210, this.alphaAnim.getAlpha()).getRGB());
                    RenderUtils.drawRoundedRect2(this.startX + 64.0f, mY + 2.0f, this.startX + 186.0f, mY + 24.0f, 5.0f, new Color(230, 230, 230, this.alphaAnim.getAlpha()).getRGB());
                    RenderUtils.drawRoundedRect2(this.startX + 65.0f, mY + 3.0f, this.startX + 185.0f, mY + 23.0f, 4.0f, new Color(colorV, colorV, colorV, this.alphaAnim.getAlpha()).getRGB());
                    if (this.isSettingsButtonHovered(this.startX + 64.0f, mY + 2.0f, this.startX + 186.0f, mY + 24.0f, mouseX, mouseY) && this.categoryAnimation < 15) {
                        this.defaultFont.func_78276_b(module.getName(), (int)(this.startX + 70.0f) + Math.round(this.moduleAnimation / 2), (int)(mY + 6.0f + 5.0f - (float)this.fontHeight), moduleColor);
                        this.defaultFont.func_78276_b("KeyBind: " + (!Keyboard.getKeyName((int)module.getKeyBind()).equalsIgnoreCase("NONE") ? Keyboard.getKeyName((int)module.getKeyBind()) : "None"), (int)(this.startX + 70.0f) + Math.round(this.moduleAnimation / 2), (int)(mY + 13.0f + 5.0f - (float)this.fontHeight), new Color(80, 80, 80, this.alphaAnim.getAlpha()).getRGB() - 14 + this.moduleAnimation * 2);
                        ++this.moduleAnimation;
                        if (this.moduleAnimation > 6) {
                            this.moduleAnimation = 6;
                        }
                        this.moduleHover = true;
                        if (Mouse.isButtonDown((int)1) && !this.rightClickMouse && this.currentModule != module) {
                            this.currentModule = module;
                            this.valueAnim.resetAlpha();
                            this.valueStart = 0;
                            this.rightClickMouse = true;
                        }
                        if (!this.previousMouse && Mouse.isButtonDown((int)0)) {
                            module.setState(!module.getState());
                            this.previousMouse = true;
                        }
                        if (!this.previousMouse && Mouse.isButtonDown((int)1)) {
                            this.previousMouse = true;
                        }
                    } else {
                        this.defaultFont.func_78276_b(module.getName(), (int)(this.startX + 70.0f), (int)(mY + 6.0f + 5.0f - (float)this.fontHeight), moduleColor);
                        this.defaultFont.func_78276_b("KeyBind: " + (!Keyboard.getKeyName((int)module.getKeyBind()).equalsIgnoreCase("NONE") ? Keyboard.getKeyName((int)module.getKeyBind()) : "None"), (int)(this.startX + 70.0f), (int)(mY + 13.0f + 5.0f - (float)this.fontHeight), new Color(80, 80, 80, this.alphaAnim.getAlpha()).getRGB());
                    }
                    if (this.rightClickMouse && !Mouse.isButtonDown((int)1)) {
                        this.rightClickMouse = false;
                    }
                    RenderUtils.drawRoundedRect2(this.startX + 160.0f, mY + 6.0f, this.startX + 180.0f, mY + 16.0f, 4.0f, module.getState() && module.getAnimation().getAnimationX() >= 3.0f ? new Color(29, 143, 237, this.alphaAnim.getAlpha()).getRGB() : new Color(114, 118, 125, this.alphaAnim.getAlpha()).getRGB());
                    RenderUtils.circle(this.startX + 170.0f + module.getAnimation().getAnimationX(), mY + 11.0f, 4.0f, module.getState() ? new Color(255, 255, 255, this.alphaAnim.getAlpha()).getRGB() : new Color(164, 168, 175, this.alphaAnim.getAlpha()).getRGB());
                    module.getAnimation().animationX = module.getState() ? (float)((double)module.getAnimation().animationX + (double)(5.0f - module.getAnimation().animationX) / 2.5) : (float)((double)module.getAnimation().animationX + (double)(-5.0f - module.getAnimation().animationX) / 2.5);
                    mY += 28.0f;
                }
            }
            mY = this.startY + 30.0f;
            if (this.currentModule.getValues().isEmpty()) {
                this.logoFont.func_78276_b("Current Module Has No Settings", (int)(this.startX + 220.0f), (int)(this.startY + 135.0f - (float)this.fontHeight), new Color(100, 100, 100, this.valueAnim.getAlpha()).getRGB());
            }
            for (int i = 0; i < this.currentModule.getValues().size() && !(mY > this.startY + 280.0f); ++i) {
                if (i < this.valueStart) continue;
                Value<?> value = this.currentModule.getValues().get(i);
                if (value instanceof FloatValue) {
                    FloatValue floatValue = (FloatValue)value;
                    float x = this.startX + 300.0f;
                    settings2.drawFloatValue(mouseX, mY, this.startX, this.previousMouse, this.isButtonHovered(x, mY - 2.0f, x + 100.0f, mY + 7.0f, mouseX, mouseY), floatValue);
                    if (!Mouse.isButtonDown((int)0)) {
                        this.previousMouse = false;
                    }
                    mY += 20.0f;
                }
                if (value instanceof IntegerValue) {
                    IntegerValue integerValue = (IntegerValue)value;
                    float x = this.startX + 300.0f;
                    settings2.drawIntegerValue(mouseX, mY, this.startX, this.previousMouse, this.isButtonHovered(x, mY - 2.0f, x + 100.0f, mY + 7.0f, mouseX, mouseY), integerValue);
                    if (!Mouse.isButtonDown((int)0)) {
                        this.previousMouse = false;
                    }
                    mY += 20.0f;
                }
                if (value instanceof Value.ColorValue) {
                    Value.ColorValue colorValue = (Value.ColorValue)value;
                    settings2.drawColorValue(this.startX, mY, this.startX + 300.0f, mouseX, mouseY, colorValue);
                    if (!Mouse.isButtonDown((int)0)) {
                        this.previousMouse = false;
                    }
                    mY += 20.0f;
                }
                if (value instanceof BoolValue) {
                    BoolValue boolValue = (BoolValue)value;
                    float x = this.startX + 325.0f;
                    settings2.drawBoolValue(this.mouse, mouseX, mouseY, this.startX, mY, boolValue);
                    if (this.isCheckBoxHovered(x + 30.0f, mY - 2.0f, x + 50.0f, mY + 8.0f, mouseX, mouseY)) {
                        if (!this.previousMouse && Mouse.isButtonDown((int)0)) {
                            this.previousMouse = true;
                            this.mouse = true;
                        }
                        if (this.mouse) {
                            boolValue.set((Boolean)boolValue.get() == false);
                            this.mouse = false;
                        }
                    }
                    mY += 20.0f;
                }
                if (value instanceof TextValue) {
                    TextValue textValue = (TextValue)value;
                    settings2.drawTextValue(this.startX, mY, textValue);
                    mY += 20.0f;
                }
                if (!(value instanceof ListValue)) continue;
                float x = this.startX + 295.0f;
                ListValue listValue = (ListValue)value;
                settings2.drawListValue(this.previousMouse, mouseX, mouseY, mY, this.startX, listValue);
                this.previousMouse = Mouse.isButtonDown((int)0);
                mY += 25.0f;
            }
        }
        if (!this.moduleHover) {
            this.moduleAnimation = 0;
        }
        if (this.currentCategory == ModuleCategory.COMBAT) {
            this.categoryYpos = 35;
        }
        if (this.currentCategory == ModuleCategory.MOVEMENT) {
            this.categoryYpos = 70;
        }
        if (this.currentCategory == ModuleCategory.WORLD) {
            this.categoryYpos = 105;
        }
        if (this.currentCategory == ModuleCategory.PLAYER) {
            this.categoryYpos = 140;
        }
        if (this.currentCategory == ModuleCategory.EXPLOIT) {
            this.categoryYpos = 175;
        }
        if (this.currentCategory == ModuleCategory.MISC) {
            this.categoryYpos = 210;
        }
        if (this.currentCategory == ModuleCategory.CLIENT) {
            this.categoryYpos = 245;
        }
        if (this.currentCategory == ModuleCategory.RENDER) {
            this.categoryYpos = 280;
        }
        if (this.categoryMouse && !Mouse.isButtonDown((int)0)) {
            this.categoryMouse = false;
        }
        if (this.isCategoryHovered(this.startX - 5.0f, this.startY + 25.0f, this.startX + 35.0f + (float)this.categoryAnimation, this.startY + 13.0f + 45.0f, mouseX, mouseY)) {
            this.categoryYpos = 35;
            if (Mouse.isButtonDown((int)0) && !this.categoryMouse && this.currentCategory != ModuleCategory.COMBAT) {
                this.currentCategory = ModuleCategory.COMBAT;
                this.categoryMouse = true;
                if (this.searchBox.getText().isEmpty()) {
                    this.moduleStart = 0;
                    this.currentModule = FDPClient.moduleManager.getModuleInCategory(this.currentCategory).get(0);
                    this.alphaAnim.resetAlpha();
                    this.valueAnim.resetAlpha();
                }
            }
        }
        if (this.isCategoryHovered(this.startX - 5.0f, this.startY + 3.0f + 55.0f, this.startX + 35.0f + (float)this.categoryAnimation, this.startY + 13.0f + 80.0f, mouseX, mouseY)) {
            this.categoryYpos = 70;
            if (Mouse.isButtonDown((int)0) && !this.categoryMouse && this.currentCategory != ModuleCategory.MOVEMENT) {
                this.currentCategory = ModuleCategory.MOVEMENT;
                this.categoryMouse = true;
                if (this.searchBox.getText().isEmpty()) {
                    this.moduleStart = 0;
                    this.currentModule = FDPClient.moduleManager.getModuleInCategory(this.currentCategory).get(0);
                    this.alphaAnim.resetAlpha();
                    this.valueAnim.resetAlpha();
                }
            }
        }
        if (this.isCategoryHovered(this.startX - 5.0f, this.startY + 3.0f + 90.0f, this.startX + 35.0f + (float)this.categoryAnimation, this.startY + 13.0f + 115.0f, mouseX, mouseY)) {
            this.categoryYpos = 105;
            if (Mouse.isButtonDown((int)0) && !this.categoryMouse && this.currentCategory != ModuleCategory.WORLD) {
                this.currentCategory = ModuleCategory.WORLD;
                this.categoryMouse = true;
                if (this.searchBox.getText().isEmpty()) {
                    this.moduleStart = 0;
                    this.currentModule = FDPClient.moduleManager.getModuleInCategory(this.currentCategory).get(0);
                    this.alphaAnim.resetAlpha();
                    this.valueAnim.resetAlpha();
                }
            }
        }
        if (this.isCategoryHovered(this.startX - 5.0f, this.startY + 3.0f + 125.0f, this.startX + 35.0f + (float)this.categoryAnimation, this.startY + 13.0f + 150.0f, mouseX, mouseY)) {
            this.categoryYpos = 140;
            if (Mouse.isButtonDown((int)0) && !this.categoryMouse && this.currentCategory != ModuleCategory.PLAYER) {
                this.currentCategory = ModuleCategory.PLAYER;
                this.categoryMouse = true;
                if (this.searchBox.getText().isEmpty()) {
                    this.moduleStart = 0;
                    this.currentModule = FDPClient.moduleManager.getModuleInCategory(this.currentCategory).get(0);
                    this.alphaAnim.resetAlpha();
                    this.valueAnim.resetAlpha();
                }
            }
        }
        if (this.isCategoryHovered(this.startX - 5.0f, this.startY + 3.0f + 160.0f, this.startX + 35.0f + (float)this.categoryAnimation, this.startY + 13.0f + 185.0f, mouseX, mouseY)) {
            this.categoryYpos = 175;
            if (Mouse.isButtonDown((int)0) && !this.categoryMouse && this.currentCategory != ModuleCategory.EXPLOIT) {
                this.currentCategory = ModuleCategory.EXPLOIT;
                this.categoryMouse = true;
                if (this.searchBox.getText().isEmpty()) {
                    this.moduleStart = 0;
                    this.currentModule = FDPClient.moduleManager.getModuleInCategory(this.currentCategory).get(0);
                    this.alphaAnim.resetAlpha();
                    this.valueAnim.resetAlpha();
                }
            }
        }
        if (this.isCategoryHovered(this.startX - 5.0f, this.startY + 3.0f + 195.0f, this.startX + 35.0f + (float)this.categoryAnimation, this.startY + 13.0f + 220.0f, mouseX, mouseY)) {
            this.categoryYpos = 210;
            if (Mouse.isButtonDown((int)0) && !this.categoryMouse && this.currentCategory != ModuleCategory.MISC) {
                this.currentCategory = ModuleCategory.MISC;
                this.categoryMouse = true;
                if (this.searchBox.getText().isEmpty()) {
                    this.moduleStart = 0;
                    this.currentModule = FDPClient.moduleManager.getModuleInCategory(this.currentCategory).get(0);
                    this.alphaAnim.resetAlpha();
                    this.valueAnim.resetAlpha();
                }
            }
        }
        if (this.isCategoryHovered(this.startX - 5.0f, this.startY + 3.0f + 230.0f, this.startX + 35.0f + (float)this.categoryAnimation, this.startY + 13.0f + 255.0f, mouseX, mouseY)) {
            this.categoryYpos = 245;
            if (Mouse.isButtonDown((int)0) && !this.categoryMouse && this.currentCategory != ModuleCategory.CLIENT) {
                this.currentCategory = ModuleCategory.CLIENT;
                this.categoryMouse = true;
                if (this.searchBox.getText().isEmpty()) {
                    this.moduleStart = 0;
                    this.currentModule = FDPClient.moduleManager.getModuleInCategory(this.currentCategory).get(0);
                    this.alphaAnim.resetAlpha();
                    this.valueAnim.resetAlpha();
                }
            }
        }
        if (this.isCategoryHovered(this.startX - 5.0f, this.startY + 3.0f + 265.0f, this.startX + 35.0f + (float)this.categoryAnimation, this.startY + 13.0f + 290.0f, mouseX, mouseY)) {
            this.categoryYpos = 280;
            if (Mouse.isButtonDown((int)0) && !this.categoryMouse && this.currentCategory != ModuleCategory.RENDER) {
                this.currentCategory = ModuleCategory.RENDER;
                this.categoryMouse = true;
                if (this.searchBox.getText().isEmpty()) {
                    this.moduleStart = 0;
                    this.currentModule = FDPClient.moduleManager.getModuleInCategory(this.currentCategory).get(0);
                    this.alphaAnim.resetAlpha();
                    this.valueAnim.resetAlpha();
                }
            }
        }
        this.categoryAnimation = this.isCategoryHovered(this.startX - 5.0f, this.startY + 25.0f, this.startX + (float)this.categoryAnimation + 53.0f, this.startY + 310.0f, mouseX, mouseY) ? (int)((long)this.categoryAnimation + Math.round((double)(50 - this.categoryAnimation) / 3.5)) : (int)((long)this.categoryAnimation + Math.round((double)(0 - this.categoryAnimation) / 3.5));
        RenderUtils.drawGradientSideways(this.startX + (float)this.categoryAnimation + 48.0f, this.startY + 25.0f, this.startX + (float)this.categoryAnimation + 55.0f, this.startY + 310.0f, new Color(0, 0, 0, 190).getRGB(), new Color(0, 0, 0, 0).getRGB());
        RenderUtils.drawGradientSideways(this.startX + 200.0f, this.startY + 25.0f, this.startX + 205.0f, this.startY + 310.0f, new Color(0, 0, 0, 70).getRGB(), new Color(0, 0, 0, 0).getRGB());
        RenderUtils.drawRoundedRect2((int)this.startX - 5, (int)this.startY + 25, (int)this.startX + 50 + this.categoryAnimation, (int)this.startY + 310, 1.0f, new Color(255, 255, 255, 250).getRGB());
        RenderUtils.drawRoundedRect2((int)this.startX + 6, (int)this.startY + this.animationHeight - 5, (int)this.startX + 38 + this.categoryAnimation, (int)this.startY + this.animationHeight + 17, 5.0f, new Color(29, 143, 237, 250).getRGB());
        if (this.categoryAnimation > 4) {
            Fonts.font40.drawString("Combat", this.startX + 30.0f + (float)Math.round(this.categoryAnimation / 5), this.startY + 35.0f + 6.0f - (float)this.fontHeight, new Color(30, 30, 30, Math.round(this.categoryAnimation * 5)).getRGB());
            Fonts.font40.drawString("Move", this.startX + 30.0f + (float)Math.round(this.categoryAnimation / 5), this.startY + 70.0f + 6.0f - (float)this.fontHeight, new Color(30, 30, 30, Math.round(this.categoryAnimation * 5)).getRGB());
            Fonts.font40.drawString("World", this.startX + 30.0f + (float)Math.round(this.categoryAnimation / 5), this.startY + 105.0f + 6.0f - (float)this.fontHeight, new Color(30, 30, 30, Math.round(this.categoryAnimation * 5)).getRGB());
            Fonts.font40.drawString("Player", this.startX + 30.0f + (float)Math.round(this.categoryAnimation / 5), this.startY + 140.0f + 6.0f - (float)this.fontHeight, new Color(30, 30, 30, Math.round(this.categoryAnimation * 5)).getRGB());
            Fonts.font40.drawString("Exploit", this.startX + 30.0f + (float)Math.round(this.categoryAnimation / 5), this.startY + 175.0f + 6.0f - (float)this.fontHeight, new Color(30, 30, 30, Math.round(this.categoryAnimation * 5)).getRGB());
            Fonts.font40.drawString("Misc", this.startX + 30.0f + (float)Math.round(this.categoryAnimation / 5), this.startY + 210.0f + 6.0f - (float)this.fontHeight, new Color(30, 30, 30, Math.round(this.categoryAnimation * 5)).getRGB());
            Fonts.font40.drawString("Client", this.startX + 30.0f + (float)Math.round(this.categoryAnimation / 5), this.startY + 245.0f + 6.0f - (float)this.fontHeight, new Color(30, 30, 30, Math.round(this.categoryAnimation * 5)).getRGB());
            Fonts.font40.drawString("Render", this.startX + 30.0f + (float)Math.round(this.categoryAnimation / 5), this.startY + 280.0f + 6.0f - (float)this.fontHeight, new Color(30, 30, 30, Math.round(this.categoryAnimation * 5)).getRGB());
        }
        this.searchBox.drawTextBox();
        int Hdiff = this.animationHeight - this.categoryYpos;
        this.animationHeight = (int)((long)this.animationHeight + Math.round((double)(this.categoryYpos - this.animationHeight) / 2.5));
        if (Hdiff > -3 && Hdiff < 0) {
            this.animationHeight = this.categoryYpos;
        }
        if (Hdiff < 3 && Hdiff > 0) {
            this.animationHeight = this.categoryYpos;
        }
        RenderUtils.drawImage(new ResourceLocation("fdpclient/ui/clickgui/light/Combat.png"), (int)this.startX + 17, (int)this.startY + 35, 12, 12);
        RenderUtils.drawImage(new ResourceLocation("fdpclient/ui/clickgui/light/Movement.png"), (int)this.startX + 17, (int)this.startY + 70, 12, 12);
        RenderUtils.drawImage(new ResourceLocation("fdpclient/ui/clickgui/light/World.png"), (int)this.startX + 17, (int)this.startY + 105, 12, 12);
        RenderUtils.drawImage(new ResourceLocation("fdpclient/ui/clickgui/light/Player.png"), (int)this.startX + 17, (int)this.startY + 140, 12, 12);
        RenderUtils.drawImage(new ResourceLocation("fdpclient/ui/clickgui/light/Exploit.png"), (int)this.startX + 17, (int)this.startY + 175, 12, 12);
        RenderUtils.drawImage(new ResourceLocation("fdpclient/ui/clickgui/light/Misc.png"), (int)this.startX + 17, (int)this.startY + 210, 12, 12);
        RenderUtils.drawImage(new ResourceLocation("fdpclient/ui/clickgui/light/Client.png"), (int)this.startX + 17, (int)this.startY + 245, 12, 12);
        RenderUtils.drawImage(new ResourceLocation("fdpclient/ui/clickgui/light/Render.png"), (int)this.startX + 17, (int)this.startY + 280, 12, 12);
    }

    public boolean isStringHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= f && (float)mouseX <= g && (float)mouseY >= y && (float)mouseY <= y2;
    }

    public boolean isSettingsButtonHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= x && (float)mouseX <= x2 && (float)mouseY >= y && (float)mouseY <= y2;
    }

    public boolean isButtonHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= f && (float)mouseX <= g && (float)mouseY >= y && (float)mouseY <= y2;
    }

    public boolean isCheckBoxHovered(float f, float y, float g, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= f && (float)mouseX <= g && (float)mouseY >= y && (float)mouseY <= y2;
    }

    public boolean isCategoryHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= x && (float)mouseX <= x2 && (float)mouseY >= y && (float)mouseY <= y2;
    }

    public boolean isHovered(float x, float y, float x2, float y2, int mouseX, int mouseY) {
        return (float)mouseX >= x && (float)mouseX <= x2 && (float)mouseY >= y && (float)mouseY <= y2;
    }
}

