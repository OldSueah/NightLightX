/*
 * Decompiled with CFR 0.152.
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.render;

public enum GuiEvents {
    DRAW,
    CLICK,
    RELEASE;

}

