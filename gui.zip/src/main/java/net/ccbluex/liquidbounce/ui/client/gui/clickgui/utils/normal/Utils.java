/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.client.gui.FontRenderer
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.normal;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;

public interface Utils {
    public static final Minecraft mc = Minecraft.func_71410_x();
    public static final FontRenderer fr = Utils.mc.field_71466_p;
}

