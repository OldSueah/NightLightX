/*
 * Decompiled with CFR 0.152.
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui.fonts.api;

import net.ccbluex.liquidbounce.ui.client.gui.clickgui.fonts.api.FontRenderer;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.fonts.api.FontType;

public interface FontFamily {
    public FontRenderer ofSize(int var1);

    public FontType font();
}

