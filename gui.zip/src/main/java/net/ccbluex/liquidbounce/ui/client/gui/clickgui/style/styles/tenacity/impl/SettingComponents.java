/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.renderer.GlStateManager
 *  net.minecraft.client.renderer.OpenGlHelper
 *  org.lwjgl.opengl.GL11
 */
package net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.tenacity.impl;

import java.awt.Color;
import java.util.HashMap;
import net.ccbluex.liquidbounce.FDPClient;
import net.ccbluex.liquidbounce.features.module.Module;
import net.ccbluex.liquidbounce.features.module.modules.client.HUD;
import net.ccbluex.liquidbounce.features.value.BoolValue;
import net.ccbluex.liquidbounce.features.value.FloatValue;
import net.ccbluex.liquidbounce.features.value.IntegerValue;
import net.ccbluex.liquidbounce.features.value.ListValue;
import net.ccbluex.liquidbounce.features.value.NumberValue;
import net.ccbluex.liquidbounce.features.value.TextValue;
import net.ccbluex.liquidbounce.features.value.Value;
import net.ccbluex.liquidbounce.ui.client.gui.ClickGUIModule;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.fonts.impl.Fonts;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.style.styles.tenacity.impl.Component;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.Animation;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.Direction;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.impl.DecelerateAnimation;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.animations.impl.EaseInOutQuad;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.normal.Main;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.objects.PasswordField;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.render.DrRenderUtils;
import net.ccbluex.liquidbounce.ui.client.gui.clickgui.utils.render.GuiEvents;
import net.ccbluex.liquidbounce.utils.MathUtils;
import net.ccbluex.liquidbounce.utils.render.RoundedUtil;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import org.lwjgl.opengl.GL11;

public class SettingComponents
extends Component {
    public static float scale;
    private final Module module;
    public Animation settingHeightScissor;
    private final HashMap<Module, Animation[]> keySettingAnimMap = new HashMap();
    private final HashMap<IntegerValue, Float> sliderintMap = new HashMap();
    private final HashMap<IntegerValue, Animation[]> sliderintAnimMap = new HashMap();
    private final HashMap<FloatValue, Float> sliderfloatMap = new HashMap();
    private final HashMap<FloatValue, Animation[]> sliderfloatAnimMap = new HashMap();
    private final HashMap<NumberValue, Float> sliderMap = new HashMap();
    private final HashMap<NumberValue, Animation[]> sliderAnimMap = new HashMap();
    private final HashMap<BoolValue, Animation[]> toggleAnimation = new HashMap();
    private final HashMap<ListValue, Animation[]> modeSettingAnimMap = new HashMap();
    private final HashMap<ListValue, Boolean> modeSettingClick = new HashMap();
    private final HashMap<ListValue, HashMap<String, Animation>> modesHoverAnimation = new HashMap();
    public Module binding;
    public Value draggingNumber;
    public float x;
    public float y;
    public float width;
    public float rectHeight;
    public float panelLimitY;
    public int alphaAnimation;
    public double settingSize;
    private PasswordField selectedField;
    private TextValue selectedStringSetting;
    private boolean hueFlag;

    public SettingComponents(Module module) {
        this.module = module;
        this.keySettingAnimMap.put(module, new Animation[]{new EaseInOutQuad(250, 1.0, Direction.BACKWARDS), new DecelerateAnimation(225, 1.0, Direction.BACKWARDS)});
        for (Value<?> setting : module.getValues()) {
            if (setting instanceof NumberValue) {
                this.sliderMap.put((NumberValue)setting, Float.valueOf(0.0f));
                this.sliderAnimMap.put((NumberValue)setting, new Animation[]{new DecelerateAnimation(250, 1.0, Direction.BACKWARDS), new DecelerateAnimation(200, 1.0, Direction.BACKWARDS)});
            }
            if (setting instanceof FloatValue) {
                this.sliderfloatMap.put((FloatValue)setting, Float.valueOf(0.0f));
                this.sliderfloatAnimMap.put((FloatValue)setting, new Animation[]{new DecelerateAnimation(250, 1.0, Direction.BACKWARDS), new DecelerateAnimation(200, 1.0, Direction.BACKWARDS)});
            }
            if (setting instanceof IntegerValue) {
                this.sliderintMap.put((IntegerValue)setting, Float.valueOf(0.0f));
                this.sliderintAnimMap.put((IntegerValue)setting, new Animation[]{new DecelerateAnimation(250, 1.0, Direction.BACKWARDS), new DecelerateAnimation(200, 1.0, Direction.BACKWARDS)});
            }
            if (setting instanceof BoolValue) {
                this.toggleAnimation.put((BoolValue)setting, new Animation[]{new DecelerateAnimation(225, 1.0, Direction.BACKWARDS), new DecelerateAnimation(200, 1.0, Direction.BACKWARDS)});
            }
            if (!(setting instanceof ListValue)) continue;
            ListValue modeSetting = (ListValue)setting;
            this.modeSettingClick.put(modeSetting, false);
            this.modeSettingAnimMap.put(modeSetting, new Animation[]{new DecelerateAnimation(225, 1.0, Direction.BACKWARDS), new EaseInOutQuad(250, 1.0, Direction.BACKWARDS)});
            HashMap<String, DecelerateAnimation> modeMap = new HashMap<String, DecelerateAnimation>();
            for (String mode : modeSetting.getValues()) {
                modeMap.put(mode, new DecelerateAnimation(225, 1.0, Direction.BACKWARDS));
            }
            this.modesHoverAnimation.put(modeSetting, modeMap);
        }
    }

    @Override
    public void initGui() {
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (this.selectedField != null) {
            if (keyCode == 1) {
                this.selectedField = null;
                this.selectedStringSetting = null;
                return;
            }
            this.selectedField.textboxKeyTyped(typedChar, keyCode);
            this.selectedStringSetting.set(this.selectedField.getText());
        }
    }

    public void handle(int mouseX, int mouseY, int button, GuiEvents type) {
        HUD hud = FDPClient.moduleManager.getModule(HUD.class);
        Color textColor = new Color(255, 255, 255, this.alphaAnimation);
        Color darkRectColor = new Color(48, 50, 55, this.alphaAnimation);
        Color darkRectColorDisabled = new Color(52, 52, 52, this.alphaAnimation);
        Color darkRectHover = DrRenderUtils.brighter(darkRectColor, 0.8f);
        Color[] colors = new Color[2];
        boolean accent = ((String)ClickGUIModule.INSTANCE.getColormode().get()).equalsIgnoreCase("Color");
        Color color2 = new Color(ClickGUIModule.INSTANCE.generateColor().getRGB());
        colors = new Color[]{color2, color2};
        Color accentedColor = DrRenderUtils.applyOpacity(colors[0], (float)this.alphaAnimation / 255.0f);
        Color accentedColor2 = DrRenderUtils.applyOpacity(colors[1], (float)this.alphaAnimation / 255.0f);
        double count = 0.0;
        for (Value<?> setting : this.module.getValues()) {
            float sliderY;
            float sliderMath;
            float percent;
            double currentValue;
            boolean hoveringSlider;
            float totalSliderWidth;
            Animation selectAnimtion;
            Object hoverAnimation;
            float titleY;
            float titleX;
            float valueFontWidth;
            float regularFontWidth;
            String value;
            Value numberSetting;
            if (!setting.getDisplayable()) continue;
            float settingY = (float)MathUtils.INSTANCE.roundToHalf((double)this.y + count * (double)this.rectHeight);
            if (setting instanceof FloatValue) {
                numberSetting = (FloatValue)setting;
                value = Float.toString((float)MathUtils.INSTANCE.round((double)((Float)numberSetting.getValue()).floatValue(), 0.01));
                regularFontWidth = Fonts.SF.SF_18.SF_18.stringWidth(numberSetting.getName() + ": ");
                valueFontWidth = Fonts.SF.SF_18.SF_18.stringWidth(value);
                titleX = this.x + this.width / 2.0f - (regularFontWidth + valueFontWidth) / 2.0f;
                titleY = settingY + Fonts.SF.SF_18.SF_18.getMiddleOfBox(this.rectHeight) - Fonts.SF.SF_18.SF_18.getMiddleOfBox(this.rectHeight) / 2.0f + 1.0f;
                GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                Fonts.SF.SF_18.SF_18.drawString((CharSequence)(numberSetting.getName() + ": "), titleX, titleY, textColor.getRGB());
                GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.drawString((CharSequence)value, titleX + regularFontWidth, titleY, textColor.getRGB());
                hoverAnimation = this.sliderfloatAnimMap.get(numberSetting)[0];
                selectAnimtion = this.sliderfloatAnimMap.get(numberSetting)[1];
                totalSliderWidth = this.width - 10.0f;
                boolean bl = hoveringSlider = this.isClickable(settingY + 17.0f) && DrRenderUtils.isHovering(this.x + 5.0f, settingY + 17.0f, totalSliderWidth, 6.0f, mouseX, mouseY);
                if (type == GuiEvents.RELEASE) {
                    this.draggingNumber = null;
                }
                ((Animation)hoverAnimation).setDirection(hoveringSlider || this.draggingNumber == numberSetting ? Direction.FORWARDS : Direction.BACKWARDS);
                selectAnimtion.setDirection(this.draggingNumber == numberSetting ? Direction.FORWARDS : Direction.BACKWARDS);
                if (type == GuiEvents.CLICK && hoveringSlider && button == 0) {
                    this.draggingNumber = numberSetting;
                }
                currentValue = ((Float)numberSetting.getValue()).floatValue();
                if (this.draggingNumber != null && this.draggingNumber == setting) {
                    percent = Math.min(1.0f, Math.max(0.0f, ((float)mouseX - (this.x + 5.0f)) / totalSliderWidth));
                    double newValue = percent * (((FloatValue)numberSetting).getMaximum() - ((FloatValue)numberSetting).getMinimum()) + ((FloatValue)numberSetting).getMinimum();
                    ((FloatValue)numberSetting).set(newValue);
                }
                sliderMath = (float)((currentValue - (double)((FloatValue)numberSetting).getMinimum()) / (double)(((FloatValue)numberSetting).getMaximum() - ((FloatValue)numberSetting).getMinimum()));
                this.sliderfloatMap.put((FloatValue)numberSetting, Float.valueOf((float)DrRenderUtils.animate(totalSliderWidth * sliderMath, this.sliderfloatMap.get(numberSetting).floatValue(), 0.1)));
                sliderY = settingY + 18.0f;
                RoundedUtil.drawRound(this.x + 5.0f, sliderY, totalSliderWidth, 3.0f, 1.5f, DrRenderUtils.applyOpacity(darkRectHover, (float)((double)0.4f + 0.2 * ((Animation)hoverAnimation).getOutput())));
                RoundedUtil.drawRound(this.x + 5.0f, sliderY, Math.max(4.0f, this.sliderfloatMap.get(numberSetting).floatValue()), 3.0f, 1.5f, accent ? accentedColor2 : textColor);
                DrRenderUtils.setAlphaLimit(0.0f);
                DrRenderUtils.fakeCircleGlow(this.x + 4.0f + Math.max(4.0f, this.sliderfloatMap.get(numberSetting).floatValue()), sliderY + 1.5f, 6.0f, Color.BLACK, 0.3f);
                DrRenderUtils.drawGoodCircle(this.x + 4.0f + Math.max(4.0f, this.sliderfloatMap.get(numberSetting).floatValue()), sliderY + 1.5f, 3.75f, accent ? accentedColor2.getRGB() : textColor.getRGB());
                count += 0.5;
            }
            if (setting instanceof IntegerValue) {
                numberSetting = (IntegerValue)setting;
                value = Float.toString((float)MathUtils.INSTANCE.round((double)((Integer)numberSetting.getValue()).intValue(), 1));
                regularFontWidth = Fonts.SF.SF_18.SF_18.stringWidth(numberSetting.getName() + ": ");
                valueFontWidth = Fonts.SF.SF_18.SF_18.stringWidth(value);
                titleX = this.x + this.width / 2.0f - (regularFontWidth + valueFontWidth) / 2.0f;
                titleY = settingY + Fonts.SF.SF_18.SF_18.getMiddleOfBox(this.rectHeight) - Fonts.SF.SF_18.SF_18.getMiddleOfBox(this.rectHeight) / 2.0f + 1.0f;
                GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                Fonts.SF.SF_18.SF_18.drawString((CharSequence)(numberSetting.getName() + ": "), titleX, titleY, textColor.getRGB());
                GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.drawString((CharSequence)value, titleX + regularFontWidth, titleY, textColor.getRGB());
                hoverAnimation = this.sliderintAnimMap.get(numberSetting)[0];
                selectAnimtion = this.sliderintAnimMap.get(numberSetting)[1];
                totalSliderWidth = this.width - 10.0f;
                boolean bl = hoveringSlider = this.isClickable(settingY + 17.0f) && DrRenderUtils.isHovering(this.x + 5.0f, settingY + 17.0f, totalSliderWidth, 6.0f, mouseX, mouseY);
                if (type == GuiEvents.RELEASE) {
                    this.draggingNumber = null;
                }
                ((Animation)hoverAnimation).setDirection(hoveringSlider || this.draggingNumber == numberSetting ? Direction.FORWARDS : Direction.BACKWARDS);
                selectAnimtion.setDirection(this.draggingNumber == numberSetting ? Direction.FORWARDS : Direction.BACKWARDS);
                if (type == GuiEvents.CLICK && hoveringSlider && button == 0) {
                    this.draggingNumber = numberSetting;
                }
                currentValue = ((Integer)numberSetting.getValue()).intValue();
                if (this.draggingNumber != null && this.draggingNumber == setting) {
                    percent = Math.min(1.0f, Math.max(0.0f, ((float)mouseX - (this.x + 5.0f)) / totalSliderWidth));
                    double newValue = percent * (float)(((IntegerValue)numberSetting).getMaximum() - ((IntegerValue)numberSetting).getMinimum()) + (float)((IntegerValue)numberSetting).getMinimum();
                    ((IntegerValue)numberSetting).set(newValue);
                }
                sliderMath = (float)((currentValue - (double)((IntegerValue)numberSetting).getMinimum()) / (double)(((IntegerValue)numberSetting).getMaximum() - ((IntegerValue)numberSetting).getMinimum()));
                this.sliderintMap.put((IntegerValue)numberSetting, Float.valueOf((float)DrRenderUtils.animate(totalSliderWidth * sliderMath, this.sliderintMap.get(numberSetting).floatValue(), 0.1)));
                sliderY = settingY + 18.0f;
                RoundedUtil.drawRound(this.x + 5.0f, sliderY, totalSliderWidth, 3.0f, 1.5f, DrRenderUtils.applyOpacity(darkRectHover, (float)((double)0.4f + 0.2 * ((Animation)hoverAnimation).getOutput())));
                RoundedUtil.drawRound(this.x + 5.0f, sliderY, Math.max(4.0f, this.sliderintMap.get(numberSetting).floatValue()), 3.0f, 1.5f, accent ? accentedColor2 : textColor);
                DrRenderUtils.setAlphaLimit(0.0f);
                DrRenderUtils.fakeCircleGlow(this.x + 4.0f + Math.max(4.0f, this.sliderintMap.get(numberSetting).floatValue()), sliderY + 1.5f, 6.0f, Color.BLACK, 0.3f);
                DrRenderUtils.drawGoodCircle(this.x + 4.0f + Math.max(4.0f, this.sliderintMap.get(numberSetting).floatValue()), sliderY + 1.5f, 3.75f, accent ? accentedColor2.getRGB() : textColor.getRGB());
                count += 0.5;
            }
            if (setting instanceof NumberValue) {
                numberSetting = (NumberValue)setting;
                value = Float.toString((float)MathUtils.INSTANCE.round((double)((Double)numberSetting.getValue()), ((NumberValue)numberSetting).getInc()));
                regularFontWidth = Fonts.SF.SF_18.SF_18.stringWidth(numberSetting.getName() + ": ");
                valueFontWidth = Fonts.SF.SF_18.SF_18.stringWidth(value);
                titleX = this.x + this.width / 2.0f - (regularFontWidth + valueFontWidth) / 2.0f;
                titleY = settingY + Fonts.SF.SF_18.SF_18.getMiddleOfBox(this.rectHeight) - Fonts.SF.SF_18.SF_18.getMiddleOfBox(this.rectHeight) / 2.0f + 1.0f;
                GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                Fonts.SF.SF_18.SF_18.drawString((CharSequence)(numberSetting.getName() + ": "), titleX, titleY, textColor.getRGB());
                GlStateManager.func_179131_c((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.drawString((CharSequence)value, titleX + regularFontWidth, titleY, textColor.getRGB());
                hoverAnimation = this.sliderAnimMap.get(numberSetting)[0];
                selectAnimtion = this.sliderAnimMap.get(numberSetting)[1];
                totalSliderWidth = this.width - 10.0f;
                boolean bl = hoveringSlider = this.isClickable(settingY + 17.0f) && DrRenderUtils.isHovering(this.x + 5.0f, settingY + 17.0f, totalSliderWidth, 6.0f, mouseX, mouseY);
                if (type == GuiEvents.RELEASE) {
                    this.draggingNumber = null;
                }
                ((Animation)hoverAnimation).setDirection(hoveringSlider || this.draggingNumber == numberSetting ? Direction.FORWARDS : Direction.BACKWARDS);
                selectAnimtion.setDirection(this.draggingNumber == numberSetting ? Direction.FORWARDS : Direction.BACKWARDS);
                if (type == GuiEvents.CLICK && hoveringSlider && button == 0) {
                    this.draggingNumber = numberSetting;
                }
                currentValue = (Double)numberSetting.getValue();
                if (this.draggingNumber != null && this.draggingNumber == setting) {
                    percent = Math.min(1.0f, Math.max(0.0f, ((float)mouseX - (this.x + 5.0f)) / totalSliderWidth));
                    double newValue = (double)percent * (((NumberValue)numberSetting).getMaximum() - ((NumberValue)numberSetting).getMinimum()) + ((NumberValue)numberSetting).getMinimum();
                    numberSetting.setValue(newValue);
                }
                sliderMath = (float)((currentValue - ((NumberValue)numberSetting).getMinimum()) / (((NumberValue)numberSetting).getMaximum() - ((NumberValue)numberSetting).getMinimum()));
                this.sliderMap.put((NumberValue)numberSetting, Float.valueOf((float)DrRenderUtils.animate(totalSliderWidth * sliderMath, this.sliderMap.get(numberSetting).floatValue(), 0.1)));
                sliderY = settingY + 18.0f;
                RoundedUtil.drawRound(this.x + 5.0f, sliderY, totalSliderWidth, 3.0f, 1.5f, DrRenderUtils.applyOpacity(darkRectHover, (float)((double)0.4f + 0.2 * ((Animation)hoverAnimation).getOutput())));
                RoundedUtil.drawRound(this.x + 5.0f, sliderY, Math.max(4.0f, this.sliderMap.get(numberSetting).floatValue()), 3.0f, 1.5f, accent ? accentedColor2 : textColor);
                DrRenderUtils.setAlphaLimit(0.0f);
                DrRenderUtils.fakeCircleGlow(this.x + 4.0f + Math.max(4.0f, this.sliderMap.get(numberSetting).floatValue()), sliderY + 1.5f, 6.0f, Color.BLACK, 0.3f);
                DrRenderUtils.drawGoodCircle(this.x + 4.0f + Math.max(4.0f, this.sliderMap.get(numberSetting).floatValue()), sliderY + 1.5f, 3.75f, accent ? accentedColor2.getRGB() : textColor.getRGB());
                count += 0.5;
            }
            if (setting instanceof BoolValue) {
                BoolValue booleanSetting = (BoolValue)setting;
                Animation toggleAnimation = this.toggleAnimation.get(booleanSetting)[0];
                Animation hoverAnimation2 = this.toggleAnimation.get(booleanSetting)[1];
                DrRenderUtils.resetColor();
                OpenGlHelper.func_148821_a((int)770, (int)771, (int)1, (int)0);
                GlStateManager.func_179147_l();
                Fonts.SF.SF_18.SF_18.drawString((CharSequence)booleanSetting.getName(), (float)((int)MathUtils.INSTANCE.roundToHalf(this.x + 4.0f)), settingY + 5.0f, textColor.getRGB());
                float switchWidth = 16.0f;
                boolean hoveringSwitch = this.isClickable(settingY + Fonts.SF.SF_18.SF_18.getMiddleOfBox(this.rectHeight) - 1.0f) && DrRenderUtils.isHovering(this.x + this.width - (switchWidth + 6.0f), settingY + Fonts.SF.SF_18.SF_18.getMiddleOfBox(this.rectHeight) - 1.0f, switchWidth, 8.0f, mouseX, mouseY);
                hoverAnimation2.setDirection(hoveringSwitch ? Direction.FORWARDS : Direction.BACKWARDS);
                if (type == GuiEvents.CLICK && hoveringSwitch && button == 0) {
                    booleanSetting.toggle();
                }
                toggleAnimation.setDirection((Boolean)booleanSetting.get() != false ? Direction.FORWARDS : Direction.BACKWARDS);
                DrRenderUtils.resetColor();
                Color accentCircle = accent ? DrRenderUtils.applyOpacity(accentedColor, 0.8f) : DrRenderUtils.darker(textColor, 0.8f);
                RoundedUtil.drawRound(this.x + this.width - (switchWidth + 5.5f), settingY + Fonts.SF.SF_18.SF_18.getMiddleOfBox(this.rectHeight) + 2.0f, switchWidth, 4.5f, 2.0f, DrRenderUtils.interpolateColorC(DrRenderUtils.applyOpacity(darkRectHover, 0.5f), accentCircle, (float)toggleAnimation.getOutput()));
                DrRenderUtils.fakeCircleGlow((float)((double)(this.x + this.width - (switchWidth + 3.0f)) + (double)(switchWidth - 5.0f) * toggleAnimation.getOutput()), settingY + Fonts.SF.SF_18.SF_18.getMiddleOfBox(this.rectHeight) + 4.0f, 6.0f, Color.BLACK, 0.3f);
                DrRenderUtils.resetColor();
                RoundedUtil.drawRound((float)((double)(this.x + this.width - (switchWidth + 6.0f)) + (double)(switchWidth - 5.0f) * toggleAnimation.getOutput()), settingY + Fonts.SF.SF_18.SF_18.getMiddleOfBox(this.rectHeight) + 1.0f, 6.5f, 6.5f, 3.0f, textColor);
            }
            if (setting instanceof ListValue) {
                boolean hoveringModeSettingRect;
                ListValue modeSetting = (ListValue)setting;
                Animation hoverAnimation3 = this.modeSettingAnimMap.get(modeSetting)[0];
                Animation openAnimation = this.modeSettingAnimMap.get(modeSetting)[1];
                boolean bl = hoveringModeSettingRect = this.isClickable(settingY + 5.0f) && DrRenderUtils.isHovering(this.x + 5.0f, settingY + 5.0f, this.width - 10.0f, this.rectHeight + 7.0f, mouseX, mouseY);
                if (type == GuiEvents.CLICK && hoveringModeSettingRect && button == 1) {
                    this.modeSettingClick.put(modeSetting, this.modeSettingClick.get(modeSetting) == false);
                }
                hoverAnimation3.setDirection(hoveringModeSettingRect ? Direction.FORWARDS : Direction.BACKWARDS);
                openAnimation.setDirection(this.modeSettingClick.get(modeSetting) != false ? Direction.FORWARDS : Direction.BACKWARDS);
                float math = (float)(modeSetting.getValues().length - 1) * this.rectHeight;
                RoundedUtil.drawRound(this.x + 5.0f, (float)((double)(settingY + this.rectHeight + 2.0f) + 12.0 * openAnimation.getOutput()), this.width - 10.0f, (float)((double)math * openAnimation.getOutput()), 3.0f, DrRenderUtils.applyOpacity(darkRectHover, (float)((double)0.35f * openAnimation.getOutput())));
                if (!openAnimation.isDone() && type == GuiEvents.DRAW) {
                    GL11.glEnable((int)3089);
                    DrRenderUtils.scissor(this.x + 5.0f, (float)((double)(settingY + 7.0f + this.rectHeight) + 3.0 * openAnimation.getOutput()), this.width - 10.0f, (float)((double)math * openAnimation.getOutput()));
                }
                float modeCount = 0.0f;
                for (String mode : modeSetting.getValues()) {
                    if (mode.equalsIgnoreCase((String)modeSetting.get())) continue;
                    float modeY = (float)((double)(settingY + this.rectHeight + 11.0f) + (double)(8.0f + modeCount * this.rectHeight) * openAnimation.getOutput());
                    DrRenderUtils.resetColor();
                    boolean hoveringMode = this.isClickable(modeY - 5.0f) && openAnimation.getDirection().equals((Object)Direction.FORWARDS) && DrRenderUtils.isHovering(this.x + 5.0f, modeY - 5.0f, this.width - 10.0f, this.rectHeight, mouseX, mouseY);
                    Animation modeHoverAnimation = this.modesHoverAnimation.get(modeSetting).get(mode);
                    modeHoverAnimation.setDirection(hoveringMode ? Direction.FORWARDS : Direction.BACKWARDS);
                    if (modeHoverAnimation.finished(Direction.FORWARDS) || !modeHoverAnimation.isDone()) {
                        RoundedUtil.drawRound(this.x + 5.0f, modeY - 5.0f, this.width - 10.0f, this.rectHeight, 3.0f, DrRenderUtils.applyOpacity(textColor, (float)((double)0.2f * modeHoverAnimation.getOutput())));
                    }
                    if (type == GuiEvents.CLICK && button == 0 && hoveringMode) {
                        this.modeSettingClick.put(modeSetting, this.modeSettingClick.get(modeSetting) == false);
                        modeSetting.set(mode);
                    }
                    if (openAnimation.isDone() && openAnimation.getDirection().equals((Object)Direction.FORWARDS) || !openAnimation.isDone()) {
                        Fonts.SF.SF_18.SF_18.drawString((CharSequence)mode, this.x + 13.0f, modeY, DrRenderUtils.applyOpacity(textColor, (float)openAnimation.getOutput()).getRGB());
                    }
                    modeCount += 1.0f;
                }
                if (!openAnimation.isDone() && type == GuiEvents.DRAW) {
                    GL11.glDisable((int)3089);
                }
                if (this.settingHeightScissor.isDone() && openAnimation.isDone() && GL11.glIsEnabled((int)3089)) {
                    GL11.glDisable((int)3089);
                }
                RoundedUtil.drawRound(this.x + 5.0f, settingY + 5.0f, this.width - 10.0f, this.rectHeight + 7.0f, 3.0f, DrRenderUtils.applyOpacity(darkRectHover, 0.45f));
                if (!hoverAnimation3.isDone() || hoverAnimation3.finished(Direction.FORWARDS)) {
                    RoundedUtil.drawRound(this.x + 5.0f, settingY + 5.0f, this.width - 10.0f, this.rectHeight + 7.0f, 3.0f, DrRenderUtils.applyOpacity(textColor, (float)((double)0.2f * hoverAnimation3.getOutput())));
                }
                float selectRectWidth = (float)((double)(this.width - 10.0f) * openAnimation.getOutput());
                if (openAnimation.isDone() && openAnimation.getDirection().equals((Object)Direction.FORWARDS) || !openAnimation.isDone()) {
                    RoundedUtil.drawRound(this.x + 5.0f + ((this.width - 10.0f) / 2.0f - selectRectWidth / 2.0f), settingY + this.rectHeight + 10.5f, Math.max(2.0f, selectRectWidth), 1.5f, 0.5f, accent ? accentedColor2 : textColor);
                }
                Fonts.SF.SF_14.SF_14.drawString((CharSequence)modeSetting.getName(), this.x + 13.0f, settingY + 9.0f, textColor.getRGB());
                DrRenderUtils.resetColor();
                Fonts.SFBOLD.SFBOLD_18.SFBOLD_18.drawString((CharSequence)modeSetting.get(), this.x + 13.0f, (float)((double)settingY + 17.5), textColor.getRGB());
                DrRenderUtils.resetColor();
                DrRenderUtils.drawClickGuiArrow(this.x + this.width - 15.0f, settingY + 17.0f, 5.0f, openAnimation, textColor.getRGB());
                count += 1.0 + (double)(math / this.rectHeight) * openAnimation.getOutput();
            }
            if (setting instanceof TextValue) {
                TextValue stringSetting = (TextValue)setting;
                DrRenderUtils.resetColor();
                Fonts.SF.SF_16.SF_16.drawString((CharSequence)stringSetting.getName(), this.x + 5.0f, settingY + 2.0f, textColor.getRGB());
                PasswordField stringSettingField = new PasswordField("Type Here...", 0, (int)(this.x + 5.0f), (int)(settingY + 15.0f), (int)(this.width - 10.0f), 10, Fonts.SF.SF_18.SF_18);
                stringSettingField.setText((String)stringSetting.get());
                stringSettingField.setFocused(this.selectedStringSetting == stringSetting);
                stringSettingField.bottomBarColor = textColor.getRGB();
                stringSettingField.textColor = textColor.getRGB();
                stringSettingField.placeHolderTextX = this.x + 30.0f;
                if (type == GuiEvents.CLICK) {
                    stringSettingField.mouseClicked(mouseX, mouseY, button);
                }
                if (stringSettingField.isFocused()) {
                    this.selectedField = stringSettingField;
                    this.selectedStringSetting = stringSetting;
                } else if (this.selectedStringSetting == stringSetting) {
                    this.selectedStringSetting = null;
                    this.selectedField = null;
                }
                stringSettingField.drawTextBox();
                stringSetting.set(stringSettingField.getText());
                count += 1.0;
            }
            count += 1.0;
        }
        this.settingSize = count;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY) {
        this.handle(mouseX, mouseY, -1, GuiEvents.DRAW);
    }

    @Override
    public void mouseClicked(int mouseX, int mouseY, int button) {
        this.handle(mouseX, mouseY, button, GuiEvents.CLICK);
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int state) {
        this.handle(mouseX, mouseY, state, GuiEvents.RELEASE);
    }

    public boolean isClickable(float y) {
        return y > this.panelLimitY && y < this.panelLimitY + 17.0f + Main.allowedClickGuiHeight;
    }
}

